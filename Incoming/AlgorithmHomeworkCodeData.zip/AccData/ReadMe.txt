1. Only 3-axes accelerometer data;
2. Data format:x,y,z,x,y,z,x,y,z...in each line of the file;
3. Acceleration range: +-8G, data resolution: 4096/1G;
4. dataset including 5 activities: sitting, squats, trot, walk and handwave; trot and walk datasets give the true steps in each file's name;