var group___s_p_i =
[
    [ "SpiTransConfig", "struct_spi_trans_config.html", [
      [ "batch_enable", "struct_spi_trans_config.html#a6bbe5b53cca4ae4901539ff1f0bf8e2b", null ],
      [ "bus_mode", "struct_spi_trans_config.html#a859044633eafe643489a7c2feea40c65", null ],
      [ "cpol_cpha_mode", "struct_spi_trans_config.html#a23ae58a82cf8157ef1b00d0df616bba1", null ],
      [ "cs_chip", "struct_spi_trans_config.html#a55422848efa0cf6927f8158d658174e9", null ],
      [ "delay_in_us", "struct_spi_trans_config.html#afc30aefc4bdf1978c66150d97d72c7ab", null ],
      [ "speed_hz", "struct_spi_trans_config.html#a01fa8ef10aae5894d3fceebc5d90a9e4", null ],
      [ "timeout", "struct_spi_trans_config.html#a5e488d3c7c2c927fa9f91684f5bb1d3b", null ],
      [ "xfer_mode", "struct_spi_trans_config.html#ae2b165be9d5d2617a6a7ff4d7e49fb3d", null ]
    ] ],
    [ "SpiMessage", "struct_spi_message.html", [
      [ "callback", "struct_spi_message.html#a2d71553d47354e27a8875849b8cfd16a", null ],
      [ "cb_param", "struct_spi_message.html#a91450432617d43ba27f2da48b7d89cfa", null ],
      [ "is_async", "struct_spi_message.html#a3ec2d3ab1cf422f0a866d0920c47dff3", null ],
      [ "rx_buf", "struct_spi_message.html#a77130b70f7d67d8e1d4b2955f5ce17d6", null ],
      [ "rx_buf_len", "struct_spi_message.html#ab6b549d1a5dcc620b8b57f8b00e8f273", null ],
      [ "rx_cont", "struct_spi_message.html#addb1fa0c2f0ee27defac9b295b0e6ef0", null ],
      [ "spec_xfer_mode", "struct_spi_message.html#aa0d318cdf9dd60b220e7dd09840c5384", null ],
      [ "tx_buf", "struct_spi_message.html#a49eb68fff3208ae17e9c2b90c6bcb423", null ],
      [ "tx_buf_len", "struct_spi_message.html#a0f822fbb927b4d17ecc37a2a77e86a70", null ]
    ] ],
    [ "SpiFlashTransInfo", "struct_spi_flash_trans_info.html", [
      [ "addr_width", "struct_spi_flash_trans_info.html#a137e5971d47e4539e860de819e44ee8b", null ],
      [ "address", "struct_spi_flash_trans_info.html#a7341204fa073a1163773a4bce6847046", null ],
      [ "bus_mode", "struct_spi_flash_trans_info.html#a2ec1f3c3e0f01e30c4e8b77ca223de12", null ],
      [ "cmd_format", "struct_spi_flash_trans_info.html#a2765a3110f043c3040ca3a08f92c7a42", null ],
      [ "cont_data", "struct_spi_flash_trans_info.html#a656e27a152e843605f6de8794cdafc73", null ],
      [ "cont_width", "struct_spi_flash_trans_info.html#a348228888924c103c8ceb136d65c211b", null ],
      [ "data_width", "struct_spi_flash_trans_info.html#a2e353fc2d93466216b6788a324173a7c", null ],
      [ "dummy_nums", "struct_spi_flash_trans_info.html#a179852db5bab710bcb75a52bd6cb6841", null ],
      [ "inst_width", "struct_spi_flash_trans_info.html#a72f818034d533e7380dc8b185b43ba4d", null ],
      [ "instruction", "struct_spi_flash_trans_info.html#abb381382ba17526824e7e11b53443aa3", null ],
      [ "trans_dir", "struct_spi_flash_trans_info.html#aa345178487891b3952e15677c094161c", null ],
      [ "trans_frame", "struct_spi_flash_trans_info.html#ac0295a57a220ac1997321d1bc5d6a0a4", null ]
    ] ],
    [ "SpiHwConfig", "struct_spi_hw_config.html", [
      [ "bus_id", "struct_spi_hw_config.html#a17d5964e3283e789e98d21f4067c819c", null ],
      [ "clk_id", "struct_spi_hw_config.html#a771bf9d4f2b172221033d6f0e1ae1d2b", null ],
      [ "cs_number", "struct_spi_hw_config.html#a97bd98e5aca00727795bd5ab1b147913", null ],
      [ "fifo_depth", "struct_spi_hw_config.html#a570be9c66248bf36462758912e9d9d76", null ],
      [ "hw_type", "struct_spi_hw_config.html#a5f7b81ea15c49c9b6a5d2ade165d914b", null ],
      [ "irq_id", "struct_spi_hw_config.html#ac487d18457c543966340e4c17d2be03a", null ],
      [ "max_speed_hz", "struct_spi_hw_config.html#a428bcfaaf9f4915dec495c0264a8d3f0", null ],
      [ "min_speed_hz", "struct_spi_hw_config.html#abbf53e72e291d878cc97f1a2cbf7fdc2", null ],
      [ "register_base", "struct_spi_hw_config.html#a634c128455f264187c0eda7338237ce7", null ],
      [ "rx_dma_enable", "struct_spi_hw_config.html#a8d457715045317b384794b34694ea20e", null ],
      [ "rx_mux_id", "struct_spi_hw_config.html#ac037054b4ef653771c610ed2d374d378", null ],
      [ "rx_trig_level", "struct_spi_hw_config.html#a7bd7db13e170c8f2206572bd9f7c93b0", null ],
      [ "spi_mode", "struct_spi_hw_config.html#a0fd5b1fdefd3fecf59574aa60bcc78f0", null ],
      [ "tx_dma_enable", "struct_spi_hw_config.html#a2aa9985f2254d225c7a1621d2de7f87f", null ],
      [ "tx_mux_id", "struct_spi_hw_config.html#a275d9aade1dcad1bd27922a07adbd32b", null ],
      [ "tx_trig_level", "struct_spi_hw_config.html#a25342420866c143cdb296220b116bacd", null ],
      [ "width_switch", "struct_spi_hw_config.html#a8302f4a2bd77f873b5299857805af503", null ]
    ] ],
    [ "SpiDevice", "struct_spi_device.html", [
      [ "bus_id", "struct_spi_device.html#adfc1a43d545e39673edb0cc6cc7800a0", null ],
      [ "ctx", "struct_spi_device.html#a93ba3076c46a650d408111a42630574d", null ],
      [ "dmac_dev", "struct_spi_device.html#af0bd3c23088c8f2465f66b61b16e5d21", null ],
      [ "hw_cfg", "struct_spi_device.html#a88235cdeb55cbfadea1c7357b387f5b8", null ],
      [ "name", "struct_spi_device.html#a6d666f2b2866bfef6043031f263d6393", null ],
      [ "ops", "struct_spi_device.html#a4329da649d23f3df9162d5bf7faedf8d", null ]
    ] ],
    [ "SpiOperations", "struct_spi_operations.html", [
      [ "irq_ins_handler", "struct_spi_operations.html#ac426ab95425521a873e31cdad74874c0", null ],
      [ "prepare_msg", "struct_spi_operations.html#af49d223c5630d1dea66ff8d2083efd79", null ],
      [ "spi_drv_init", "struct_spi_operations.html#a994ea6ea2491beadfe327b5a77cc016a", null ],
      [ "spi_flash_transfer", "struct_spi_operations.html#a416c76a47d49498b05e3754f7c107815", null ],
      [ "stop", "struct_spi_operations.html#a7719d5226d7965b1e370f9864ac87f13", null ],
      [ "transfer_one_msg", "struct_spi_operations.html#a64777e787480ca216337304e030295eb", null ]
    ] ],
    [ "HAL_SPI_DEV_MAX", "group___s_p_i.html#gaf8b47689d5687925e446166faa7da330", null ],
    [ "SPI_DMA_BUFF_SIZE", "group___s_p_i.html#gaea43dbc76f599449d753267f7b5d9c1e", null ],
    [ "SPI_NAME_SIZE", "group___s_p_i.html#ga067fc415240dc0cb9864b5657cd8e9be", null ],
    [ "SpiBatchCtrl", "group___s_p_i.html#ga4072f6655b5d18c02321daff83a6e4f8", null ],
    [ "SpiBusMode", "group___s_p_i.html#ga2900b027194d960f0b886a925037ed76", null ],
    [ "SpiCpolCphaMode", "group___s_p_i.html#ga98d7b7fbd2f7d4012ee8643f5039b1f4", null ],
    [ "SpiCsId", "group___s_p_i.html#ga6debd3969878139ca2f8461b96595cf6", null ],
    [ "SpiDevice", "group___s_p_i.html#gab625e746d5fee75f252177cdfc58e3d4", null ],
    [ "SpiFlashCmdFormat", "group___s_p_i.html#ga4b93d24c8110c2f161a90decc6464781", null ],
    [ "SpiFlashTransFrame", "group___s_p_i.html#ga15b8037743aa4316838d8df585bd1c63", null ],
    [ "SpiFlashTransInfo", "group___s_p_i.html#ga12b176bb6e3e5a43e23be20eca3c1ec7", null ],
    [ "SpiHwConfig", "group___s_p_i.html#gaac3a25d76f8e4f1b4902e0c45373d090", null ],
    [ "SpiHwType", "group___s_p_i.html#ga019bdedf82eb2b55542675e060e563ba", null ],
    [ "SpiIdDef", "group___s_p_i.html#ga880358b975d26177711e6433afa96acb", null ],
    [ "SpiMessage", "group___s_p_i.html#ga98aef2cdbeeb96292d27cdcebb832b4c", null ],
    [ "SpiMode", "group___s_p_i.html#gab3a595189067907e37206c6931593a44", null ],
    [ "SpiOperations", "group___s_p_i.html#ga8878c528789bba162faa71c390ee2aa4", null ],
    [ "SpiTransConfig", "group___s_p_i.html#gaa5b804e0db52e69600dee62644aa3af4", null ],
    [ "SpiWorkMode", "group___s_p_i.html#ga8a02a0be90c4e8cd10f9e99d2968256b", null ],
    [ "SpiBatchCtrl", "group___s_p_i.html#ga1ded4ff068c12d3815e8836cd056b113", [
      [ "SPI_BATCH_DISABLE", "group___s_p_i.html#gga1ded4ff068c12d3815e8836cd056b113acb2e905f9471c1ca8645585ceb0ee9f9", null ],
      [ "SPI_BATCH_ENABLE", "group___s_p_i.html#gga1ded4ff068c12d3815e8836cd056b113a0e8b6cdc64d2b2d2cf8261c7d5a27c75", null ]
    ] ],
    [ "SpiBusMode", "group___s_p_i.html#ga761a95a3a49a31f16cb7835ae0c3fc64", [
      [ "SPI_BUS_STANDARD", "group___s_p_i.html#gga761a95a3a49a31f16cb7835ae0c3fc64addfcdbf24d777183fcc7105f1db4de09", null ],
      [ "SPI_BUS_DUAL", "group___s_p_i.html#gga761a95a3a49a31f16cb7835ae0c3fc64aa6c85cce7f72d8fa7708ec259136f865", null ],
      [ "SPI_BUS_QUAD", "group___s_p_i.html#gga761a95a3a49a31f16cb7835ae0c3fc64ad0fdec58468eb3e178f55cc810af6ebc", null ]
    ] ],
    [ "SpiCpolCphaMode", "group___s_p_i.html#gaf4fd2033fa637493afc1ad99eb3e1027", [
      [ "SPI_CPOL_CPHA_MODE0", "group___s_p_i.html#ggaf4fd2033fa637493afc1ad99eb3e1027a8e911123fb9e7e918a681484a04a1dd1", null ],
      [ "SPI_CPOL_CPHA_MODE1", "group___s_p_i.html#ggaf4fd2033fa637493afc1ad99eb3e1027a1ce819661f32561c6d238e444e573eb9", null ],
      [ "SPI_CPOL_CPHA_MODE2", "group___s_p_i.html#ggaf4fd2033fa637493afc1ad99eb3e1027a0cbcc34b5fd8dedc13d9566213445c8c", null ],
      [ "SPI_CPOL_CPHA_MODE3", "group___s_p_i.html#ggaf4fd2033fa637493afc1ad99eb3e1027a9556adbb71a23e57db9af41b03a3b3a5", null ]
    ] ],
    [ "SpiCsId", "group___s_p_i.html#ga1e4fca1bfb6022d80b33c5cacb319482", [
      [ "SPI_CS_ID_0", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482a12b5d1bbca02cec563bebe3a3c9118b8", null ],
      [ "SPI_CS_ID_1", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482a17d81e8f45cd28d39ed8c1a50dff76f3", null ],
      [ "SPI_CS_ID_2", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482afcbb0af3e30b9e45258cfdda1f0bc76c", null ],
      [ "SPI_CS_ID_3", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482a941ce8621473baebf50b386d1c42872e", null ],
      [ "SPI_CS_ID_4", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482ac1f675f0e01cb10f806dfd7c07797334", null ],
      [ "SPI_CS_ID_5", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482a429900ebc4a79308c668986aa9e8e040", null ],
      [ "SPI_CS_ID_6", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482a81161b90e7a21e3889cadf7fba8b9070", null ],
      [ "SPI_CS_ID_7", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482a383aa82f2dc8a892fde637247975976c", null ],
      [ "SPI_CS_ID_MAX", "group___s_p_i.html#gga1e4fca1bfb6022d80b33c5cacb319482ac3a3702d9af7d10a323988df37e28cdc", null ]
    ] ],
    [ "SpiFlashCmdFormat", "group___s_p_i.html#ga99102bbc192ed66bee914bedd7e0666f", [
      [ "SPIFLASH_INST_ADDR_IN_STAND", "group___s_p_i.html#gga99102bbc192ed66bee914bedd7e0666fa743e27fc74325dbd742707d1bcb1c8c7", null ],
      [ "SPIFLASH_INST_IN_STAND", "group___s_p_i.html#gga99102bbc192ed66bee914bedd7e0666fa71fd7fb1cd401e91cdef4c5b645dd07f", null ],
      [ "SPIFLASH_INST_ADDR_DATA_IN_STD_SEL", "group___s_p_i.html#gga99102bbc192ed66bee914bedd7e0666faaa79f40ff127c814e1881820ddbef3ab", null ]
    ] ],
    [ "SpiFlashTransFrame", "group___s_p_i.html#ga670ffad0a3629b1371e7b769e74415cc", [
      [ "SPIFLASH_TRANS_FRAME_NONE", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415cca6362f22eafa185d51551051bc5b11a00", null ],
      [ "SPIFLASH_TRANS_FRAME_D", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415ccabd4e269625d3c9c05bcb3f20ca7e1e47", null ],
      [ "SPIFLASH_TRANS_FRAME_I", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415cca26ad2e1a3828bf33a559ec8192966fcb", null ],
      [ "SPIFLASH_TRANS_FRAME_IA", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415cca660a7eb8ec907cc14694c9eadbbbbbb9", null ],
      [ "SPIFLASH_TRANS_FRAME_ID", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415ccaefd1389f098a078bff4072e97f584a78", null ],
      [ "SPIFLASH_TRANS_FRAME_IAD", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415cca88e6b9d016ed4f8018479fb6b01686ff", null ],
      [ "SPIFLASH_TRANS_FRAME_IAUD", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415cca85d6e9b81f8238731e77b024e06806c0", null ],
      [ "SPIFLASH_TRANS_FRAME_ACUD", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415cca16f320e5de63174ddb48075bcca96614", null ],
      [ "SPIFLASH_TRANS_FRAME_AUD", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415cca6f709e81345d89f7e5f4b2b451c37510", null ],
      [ "SPIFLASH_TRANS_FRAME_IACUD", "group___s_p_i.html#gga670ffad0a3629b1371e7b769e74415ccaaabdad9b51fc0ef3f5333505d07bd168", null ]
    ] ],
    [ "SpiHwType", "group___s_p_i.html#ga98903d9883a3de4176629717196e8665", [
      [ "SPI_HW_TYPE_QSPI", "group___s_p_i.html#gga98903d9883a3de4176629717196e8665a4be045ed05a5d3f91d51750c782925ad", null ],
      [ "SPI_HW_TYPE_SPI", "group___s_p_i.html#gga98903d9883a3de4176629717196e8665a8719cec3b844982f14e7c790fdb9cfad", null ]
    ] ],
    [ "SpiIdDef", "group___s_p_i.html#ga7c794c238550c63db25241e37e6d150c", [
      [ "SPI_ID_QSPI", "group___s_p_i.html#gga7c794c238550c63db25241e37e6d150ca80edca6900dcf704473d8241ee086cac", null ],
      [ "SPI_ID_SPI0", "group___s_p_i.html#gga7c794c238550c63db25241e37e6d150ca71bb55289e8e97e44c8f87abec137515", null ],
      [ "SPI_ID_SPI1", "group___s_p_i.html#gga7c794c238550c63db25241e37e6d150ca9f78dc8878ec59fd75615b024262c8f5", null ],
      [ "SPI_ID_SPI2", "group___s_p_i.html#gga7c794c238550c63db25241e37e6d150ca5e7c777766d91ba6841f38cc342d3010", null ],
      [ "SPI_ID_SPI3", "group___s_p_i.html#gga7c794c238550c63db25241e37e6d150caae2e8479d46c3b5c764eb5a7ddfb28c1", null ],
      [ "SPI_ID_MAX", "group___s_p_i.html#gga7c794c238550c63db25241e37e6d150cafebf52f10dbbe467ffad98700434f5a9", null ]
    ] ],
    [ "SpiMode", "group___s_p_i.html#ga2db784da2e3e41534ab2dbdd58851b2f", [
      [ "SPI_MODE_MASTER", "group___s_p_i.html#gga2db784da2e3e41534ab2dbdd58851b2fae68a8adf6e5b67a7bdbe9526b15dae99", null ],
      [ "SPI_MODE_SLAVE", "group___s_p_i.html#gga2db784da2e3e41534ab2dbdd58851b2fad1131ed33ad43ab3f667070b04454439", null ]
    ] ],
    [ "SpiWorkMode", "group___s_p_i.html#ga828298ee091c625f3f29c27ab557925d", [
      [ "SPI_WORK_MODE_TX", "group___s_p_i.html#gga828298ee091c625f3f29c27ab557925da952621dd2b2be2b92b9b47a735e51d9d", null ],
      [ "SPI_WORK_MODE_RX", "group___s_p_i.html#gga828298ee091c625f3f29c27ab557925dab8e81d0d6ff4c6b73f7df566df1c14cb", null ],
      [ "SPI_WORK_MODE_FULL_DUPLEX", "group___s_p_i.html#gga828298ee091c625f3f29c27ab557925da84054e995f761504e4b73a8ef5166faa", null ],
      [ "SPI_WORK_MODE_NORFLASH_READ", "group___s_p_i.html#gga828298ee091c625f3f29c27ab557925dab81640848a95603de49f7b87430bc05b", null ]
    ] ],
    [ "hal_spi_add_dev", "group___s_p_i.html#gaedbfc6f29ca355e09994601fb46c06d3", null ],
    [ "hal_spi_drv_init", "group___s_p_i.html#ga083d3dc442844811ab6d5be4d5598ba8", null ],
    [ "hal_spi_fill_msg", "group___s_p_i.html#gaa00b7477c7f781e1258480a0f88204fc", null ],
    [ "hal_spi_get_dev_by_id", "group___s_p_i.html#ga5d3f7995d94d165721cd276dee1f0433", null ],
    [ "hal_spi_irq_handler", "group___s_p_i.html#gab8ffa3085c515732ba8672dbed96f964", null ],
    [ "hal_spi_remove_dev", "group___s_p_i.html#ga79f1a9dd3486ba597c250645af86c2f4", null ],
    [ "hal_spi_stop", "group___s_p_i.html#gad0f89c8eda00ca571fd0f77710409123", null ],
    [ "hal_spi_transfer", "group___s_p_i.html#gab1aaf2e219baba4988a7db81ab3f9a02", null ],
    [ "hal_spiflash_transfer", "group___s_p_i.html#ga8569da6e3ca2332d4c0c4b07553cf1a1", null ]
];