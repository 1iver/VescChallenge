var group___m_a_i_l_b_o_x =
[
    [ "MboxHwConfig", "struct_mbox_hw_config.html", [
      [ "ack_irq_id", "struct_mbox_hw_config.html#ad675dfb9c036fe982768df3140aafd6b", null ],
      [ "base", "struct_mbox_hw_config.html#a7b1929c509a76544a70794ea272fd0fa", null ],
      [ "clk_id", "struct_mbox_hw_config.html#acbf40cdbc448b327cc97589ce18e774c", null ],
      [ "req_irq_id", "struct_mbox_hw_config.html#a3d9c31a1b6ac095e0ca4dcbb6e970b1a", null ]
    ] ],
    [ "MboxDevice", "struct_mbox_device.html", [
      [ "ctx", "struct_mbox_device.html#acaa70da742a7b38c80a795ea83c67ae3", null ],
      [ "hw_config", "struct_mbox_device.html#ac475882692acb109921016a2048af43c", null ],
      [ "hw_id", "struct_mbox_device.html#acc126267cd88287bc2bdf3be8de60f6a", null ],
      [ "ops", "struct_mbox_device.html#a7fac669d7e61b61940deece13f437015", null ]
    ] ],
    [ "MboxOperations", "struct_mbox_operations.html", [
      [ "ack_irq_handler", "struct_mbox_operations.html#a059e5962b4aac448f1fa699dd2254289", null ],
      [ "enable", "struct_mbox_operations.html#a686855f99a7049352e5ba373a123e686", null ],
      [ "init", "struct_mbox_operations.html#ac16bfcbaefa8560fc76bb4e44c3e354b", null ],
      [ "irq_register", "struct_mbox_operations.html#af7ba39dd5b670b59bcffd7785b54bebb", null ],
      [ "req_irq_handler", "struct_mbox_operations.html#a5b0d638a0379d0b23a1d88bff1efb4ae", null ],
      [ "request", "struct_mbox_operations.html#a0450d8e804994035109afeaa022af12e", null ]
    ] ],
    [ "MBOX_DEVICE_MAX", "group___m_a_i_l_b_o_x.html#gacb40573c1950d0a5fce8ab60ae34b83e", null ],
    [ "MboxHandler", "group___m_a_i_l_b_o_x.html#ga9cc852f863aed1fa4af1f4427c2a2a86", null ],
    [ "MboxHwConfig", "group___m_a_i_l_b_o_x.html#gad3d7d1c91c370dd0cd588fd8c0275289", null ],
    [ "MboxOperations", "group___m_a_i_l_b_o_x.html#ga771ea137a5b5a75a5c70dab4a0c12467", null ],
    [ "hal_mbox_ack_irq_handler", "group___m_a_i_l_b_o_x.html#ga4e87c0a540734b5873fe1c48592782db", null ],
    [ "hal_mbox_add_dev", "group___m_a_i_l_b_o_x.html#ga1b62d389102e616f3bb8afc69bdcfada", null ],
    [ "hal_mbox_enable", "group___m_a_i_l_b_o_x.html#ga149c085e93d315dd660c0edd77f3aa14", null ],
    [ "hal_mbox_get_device", "group___m_a_i_l_b_o_x.html#gafd962810b235a444a16fbf3e9a5ac523", null ],
    [ "hal_mbox_init", "group___m_a_i_l_b_o_x.html#gabd416b5abac114db6af359c7439e7d03", null ],
    [ "hal_mbox_irq_register", "group___m_a_i_l_b_o_x.html#ga04cc2cffc1bb22bcf8c65ea5bb349e18", null ],
    [ "hal_mbox_req_irq_handler", "group___m_a_i_l_b_o_x.html#gab9e131e5a65545fceea83f06e58346c3", null ],
    [ "hal_mbox_request", "group___m_a_i_l_b_o_x.html#ga767d4f0078b7f63b7479724247d1192a", null ]
];