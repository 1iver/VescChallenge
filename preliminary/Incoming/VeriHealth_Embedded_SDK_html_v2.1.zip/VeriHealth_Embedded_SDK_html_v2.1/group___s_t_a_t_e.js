var group___s_t_a_t_e =
[
    [ "EACH_TASK_INFO_SIZE", "group___s_t_a_t_e.html#ga835f252d67cfb7b712cc398ede16e746", null ],
    [ "TASK_ALIVE_CHAR", "group___s_t_a_t_e.html#ga7b4de4508c9ae9ba16e98c6b321a6dbe", null ],
    [ "TASK_BLOCKED_CHAR", "group___s_t_a_t_e.html#ga9d560bfa17498bb90ac2fd0514bc96fa", null ],
    [ "TASK_DEAD_CHAR", "group___s_t_a_t_e.html#ga5bcaa2da530aaa99d3ace112027b77ec", null ],
    [ "TASK_DELETED_CHAR", "group___s_t_a_t_e.html#ga9cfe875e05390212486b716f997f9a0f", null ],
    [ "TASK_READY_CHAR", "group___s_t_a_t_e.html#ga9109715e3072108b33c3e69b79c5500d", null ],
    [ "TASK_RUNNING_CHAR", "group___s_t_a_t_e.html#gacf084a11eebd866175a9c3f9a8e14112", null ],
    [ "TASK_SUSPENDED_CHAR", "group___s_t_a_t_e.html#ga777eb2a3b765d9011421352dde5717c9", null ],
    [ "osal_dump_heap_size", "group___s_t_a_t_e.html#ga432fb3dfd298aabac09302a867dfbce9", null ],
    [ "osal_dump_os_state", "group___s_t_a_t_e.html#gaecc22cb144bb5a1aec324c3d332d14b8", null ],
    [ "osal_get_free_heap", "group___s_t_a_t_e.html#gafb5e675d93893cc969dcf3cf6dd1be06", null ]
];