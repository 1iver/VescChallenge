var group___l_i_s_t =
[
    [ "ListPool", "struct_list_pool.html", [
      [ "item_size", "struct_list_pool.html#a4f316c90a060fd76c0b2da72b9ae2af0", null ],
      [ "length", "struct_list_pool.html#af948eaa80d69a549cee5560d53c3b89e", null ],
      [ "lock", "struct_list_pool.html#a2f4d913b7c81cb540e740d9e68962f7d", null ],
      [ "pool_head", "struct_list_pool.html#a53552816c03be196f5baf691242cd6a1", null ]
    ] ],
    [ "list_head", "structlist__head.html", [
      [ "next", "structlist__head.html#ac3b0ff0dfb978a0cfbdad6b9d19cdcfe", null ],
      [ "pre", "structlist__head.html#aae3223ee9015269f8f33cafe76709c95", null ]
    ] ],
    [ "ListPool", "group___l_i_s_t.html#ga5717a457fb9a0e3b232bd2d9d8b846f3", null ],
    [ "vpi_pool_get_buf", "group___l_i_s_t.html#ga51518def6883979df2620298c2ba324f", null ],
    [ "vpi_pool_init", "group___l_i_s_t.html#ga211573624aa97161d997484fd088804a", null ],
    [ "vpi_pool_put_buf_back", "group___l_i_s_t.html#gab89e26004aae36362d306eeb8970e915", null ]
];