var dir_e71060d1afa14e89e4edc07d70e39e27 =
[
    [ "arch_api.h", "arch__api_8h.html", "arch__api_8h" ],
    [ "board.h", "board_8h.html", "board_8h" ],
    [ "bsp.h", "bsp_8h.html", "bsp_8h" ],
    [ "bsp_sysctl.h", "bsp__sysctl_8h.html", "bsp__sysctl_8h" ],
    [ "device.h", "device_8h.html", "device_8h" ],
    [ "flash_partition.h", "flash__partition_8h.html", "flash__partition_8h" ],
    [ "FreeRTOSConfig.h", "_free_r_t_o_s_config_8h.html", "_free_r_t_o_s_config_8h" ],
    [ "heap_4_noncache.h", "heap__4__noncache_8h.html", "heap__4__noncache_8h" ],
    [ "otp_layout.h", "otp__layout_8h.html", "otp__layout_8h" ],
    [ "platform.h", "platform_8h.html", "platform_8h" ],
    [ "portmacro.h", "portmacro_8h.html", "portmacro_8h" ],
    [ "qemu_board.h", "qemu__board_8h.html", "qemu__board_8h" ],
    [ "soc_init.h", "soc__init_8h.html", "soc__init_8h" ],
    [ "soc_pin_define.h", "soc__pin__define_8h.html", "soc__pin__define_8h" ],
    [ "soc_pinmux.h", "soc__pinmux_8h.html", "soc__pinmux_8h" ],
    [ "sys_common.h", "sys__common_8h.html", "sys__common_8h" ]
];