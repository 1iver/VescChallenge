var group___s_w___t_i_m_e_r =
[
    [ "INVALID_TIMER", "group___s_w___t_i_m_e_r.html#gab9d72f5b28591de763472d07f5598bbe", null ],
    [ "TIMER_ERROR", "group___s_w___t_i_m_e_r.html#ga7941dbec9b2f72fb70a69af00123daf1", null ],
    [ "TIMER_OK", "group___s_w___t_i_m_e_r.html#gab3678833c7c2631a42e414469943c8f3", null ],
    [ "WAIT_FOREVER", "group___s_w___t_i_m_e_r.html#gac89d2c332821be06166c210249b671e7", null ],
    [ "VsTimerHandler", "group___s_w___t_i_m_e_r.html#ga2e3160dd661a7fb47ce6d0f86b9ece9d", null ],
    [ "VsTimerType", "group___s_w___t_i_m_e_r.html#gaf8e9cd780628e804ff6ad65864c03680", [
      [ "VS_TIMER_SW_ONE_SHOT", "group___s_w___t_i_m_e_r.html#ggaf8e9cd780628e804ff6ad65864c03680aeed1e65756017cd14f64946dbb71c7f7", null ],
      [ "VS_TIMER_SW_REPEAT", "group___s_w___t_i_m_e_r.html#ggaf8e9cd780628e804ff6ad65864c03680a3be450d1061b53907bf2186a6a9a2a56", null ],
      [ "VS_TIMER_SW_ALARM", "group___s_w___t_i_m_e_r.html#ggaf8e9cd780628e804ff6ad65864c03680a46f32a6364d5eafc1bc112720e2f0193", null ]
    ] ],
    [ "vpi_timer_create", "group___s_w___t_i_m_e_r.html#ga84ec06e94a37b50bc81bf09ad348ed3d", null ],
    [ "vpi_timer_delete", "group___s_w___t_i_m_e_r.html#gaa6ee8e9a61177bae29106563dfa9140f", null ],
    [ "vpi_timer_init", "group___s_w___t_i_m_e_r.html#ga7697ae897df447e26b53cc0d51103307", null ],
    [ "vpi_timer_reset", "group___s_w___t_i_m_e_r.html#ga22729feb92173808f3f0bd10398f6b9a", null ],
    [ "vpi_timer_reset_from_isr", "group___s_w___t_i_m_e_r.html#gaa26969f7645a22dfa5f50c5d47a0f50c", null ],
    [ "vpi_timer_start", "group___s_w___t_i_m_e_r.html#ga81350d4ba9aaf7887df22ac9b1c1a272", null ],
    [ "vpi_timer_start_from_isr", "group___s_w___t_i_m_e_r.html#ga4a0a9d134867a790d678c1d8b769674c", null ],
    [ "vpi_timer_stop", "group___s_w___t_i_m_e_r.html#ga9833a912f8bc8204a666eeb80faa9103", null ],
    [ "vpi_timer_stop_from_isr", "group___s_w___t_i_m_e_r.html#gaa9aa50dd1b3760687c1a17670856dd99", null ]
];