var group___u_s_b =
[
    [ "UsbHostCfg", "struct_usb_host_cfg.html", [
      [ "clk_id", "struct_usb_host_cfg.html#ac781e1295ca506c8b1a1b795abd29c8d", null ],
      [ "dma_enable", "struct_usb_host_cfg.html#ad5117bab353834dfe8a911e69641da30", null ],
      [ "gpd_id", "struct_usb_host_cfg.html#a52f5d401405c619a5fbda6b3eda6a5ee", null ],
      [ "irq_id", "struct_usb_host_cfg.html#a1e121bdee015a4d75d5433b6c5a9fdc5", null ],
      [ "mps", "struct_usb_host_cfg.html#a7667b2d0074c546016d473652e24465d", null ],
      [ "reg_base", "struct_usb_host_cfg.html#a561b4cff1364e9b368afdc78fd7f9e15", null ],
      [ "sof_output", "struct_usb_host_cfg.html#aeb490ca3f0ff9cd61ca35a342e8db4ea", null ],
      [ "speed", "struct_usb_host_cfg.html#a4cf58269cb9fbd547f8e32d3d5c4bcf8", null ]
    ] ],
    [ "UsbDeviceCfg", "struct_usb_device_cfg.html", [
      [ "clk_id", "struct_usb_device_cfg.html#accd78a24741b4bb8d1fa86d5f1398eef", null ],
      [ "deveps", "struct_usb_device_cfg.html#ab38f608e1f972338f23c36c9e455e254", null ],
      [ "dma_enable", "struct_usb_device_cfg.html#a0b8715ee19156719bd875f5649db5226", null ],
      [ "gpd_id", "struct_usb_device_cfg.html#adde410f34bb6b2778524883bcd4fe935", null ],
      [ "irq_id", "struct_usb_device_cfg.html#ab63161b81f5af914f6b9b3d7e0baabed", null ],
      [ "mountflash", "struct_usb_device_cfg.html#a81ef60acf53161715460c303da513b01", null ],
      [ "mps", "struct_usb_device_cfg.html#a2b7dee3de2bc0f519aed674600963e76", null ],
      [ "partitionnum", "struct_usb_device_cfg.html#a4d107fc96a35e1e88ad46c314cced805", null ],
      [ "reg_base", "struct_usb_device_cfg.html#ac6659267fd38cd71f3299ac12b653e6d", null ],
      [ "speed", "struct_usb_device_cfg.html#ac97cd9b3c0dff638278bed52b2b44382", null ]
    ] ],
    [ "UsbHwConfig", "struct_usb_hw_config.html", [
      [ "device", "struct_usb_hw_config.html#aa9bc45a9ea58655803727f218a05586c", null ],
      [ "host", "struct_usb_hw_config.html#a6096f5975776a8f3805054ad917150dd", null ],
      [ "port", "struct_usb_hw_config.html#a0ec3d56d9f296925a32e54efa67780f0", null ]
    ] ],
    [ "MscUDiskOpers", "struct_msc_u_disk_opers.html", [
      [ "getstatus", "struct_msc_u_disk_opers.html#a5610d52b581ac99b715917c9490c6af8", null ],
      [ "init", "struct_msc_u_disk_opers.html#a250ca621d98df11d296c12194579bbad", null ],
      [ "ioctl", "struct_msc_u_disk_opers.html#a8f56eeab6a5e2aad9a40e632c47a4f6b", null ],
      [ "read", "struct_msc_u_disk_opers.html#a2f1b8eff29aba9cabe247c0a05b9d613", null ],
      [ "write", "struct_msc_u_disk_opers.html#abf491514a98ec9af9cdf367d4a91b21c", null ]
    ] ],
    [ "UsbHostOpers", "struct_usb_host_opers.html", [
      [ "deinit", "struct_usb_host_opers.html#a80d30ec05d03b5d18230aeaf75d5ff66", null ],
      [ "device_connect", "struct_usb_host_opers.html#ad32d62bfcb85f13d5472f0b4fe404627", null ],
      [ "enumerate", "struct_usb_host_opers.html#a107bd97cdac76aa9525dfc8d24c93a25", null ],
      [ "init", "struct_usb_host_opers.html#adebda3fe5902d6fab733b5f488d283bd", null ],
      [ "irq_handler", "struct_usb_host_opers.html#a133185d03bba5d4460808eb9c8bca0f2", null ],
      [ "udiskopers", "struct_usb_host_opers.html#a62ec977cc98c6f4146e228f057eebcc6", null ]
    ] ],
    [ "UsbDevOpers", "struct_usb_dev_opers.html", [
      [ "deinit", "struct_usb_dev_opers.html#aaa591303a389a7e625403806f74e67cc", null ],
      [ "init", "struct_usb_dev_opers.html#ae2a96d9f63307130c2f16a6473f49d7d", null ],
      [ "irq_handler", "struct_usb_dev_opers.html#a4b476bf4f8b225f53234525ed1c4ca21", null ],
      [ "process", "struct_usb_dev_opers.html#a06d9b81f21c5c3a78b9c7c51e9f06f0a", null ]
    ] ],
    [ "UsbHostDevice", "struct_usb_host_device.html", [
      [ "opers", "struct_usb_host_device.html#a6dcdfe7cb7f1f5ad07e305f922fb3e6d", null ]
    ] ],
    [ "UsbDevDevice", "struct_usb_dev_device.html", [
      [ "opers", "struct_usb_dev_device.html#abd06dd97a9f7622f47772346e4c1d08b", null ]
    ] ],
    [ "UsbActDevice", "union_usb_act_device.html", [
      [ "device", "union_usb_act_device.html#a94c655df4effdad4596a065abc958199", null ],
      [ "host", "union_usb_act_device.html#ad55b3c655a250f3c64627501ccd91bb0", null ]
    ] ],
    [ "UsbDevice", "struct_usb_device.html", [
      [ "actdev", "struct_usb_device.html#a9d4d32f8768936e380ad268d8afa158e", null ],
      [ "cfg", "struct_usb_device.html#a87c0bc2e32fcb254757f4647d09c2209", null ],
      [ "ctx", "struct_usb_device.html#a77ddd17082a40c544c7c172fc6c1a409", null ],
      [ "port", "struct_usb_device.html#aeb3ccc0c295e12630028f4b33d63c75c", null ],
      [ "workrole", "struct_usb_device.html#a6f25d651322d73bf07aedca45057eb14", null ]
    ] ],
    [ "USB_IF_NUMS", "group___u_s_b.html#ga59eee1f76ca747b2eb7b19ff566b1976", null ],
    [ "MscUDiskOpers", "group___u_s_b.html#ga6781df131eadbf9cdfa129f4c98f8f2d", null ],
    [ "UsbActDevice", "group___u_s_b.html#ga42a870a5e6fb6b956e172ba91462861a", null ],
    [ "UsbDevDevice", "group___u_s_b.html#ga14fce678b7344da2813e32f5b813e4b6", null ],
    [ "UsbDevice", "group___u_s_b.html#gaa9e14d228ce733dda7fb0063b0e94f80", null ],
    [ "UsbDeviceCfg", "group___u_s_b.html#ga5ce53c9ae1d7e6feb454c4868a7b2b47", null ],
    [ "UsbDevOpers", "group___u_s_b.html#gaa49972f1fb213882e47a45f62a3f78cb", null ],
    [ "UsbHostCfg", "group___u_s_b.html#ga5dbd2ecf2e289079f17a781bad6e4ffd", null ],
    [ "UsbHostDevice", "group___u_s_b.html#gab1df100e33c0dc2d897546058278e599", null ],
    [ "UsbHostOpers", "group___u_s_b.html#gac7991dc2359fc06f10e739531fe54a18", null ],
    [ "UsbHwConfig", "group___u_s_b.html#ga4480c38ae90aa0704cff8e334d1dad27", null ],
    [ "UsbId", "group___u_s_b.html#ga8ddc8c334f02025d4ef596ecb9dfe7aa", null ],
    [ "UsbRole", "group___u_s_b.html#ga25f5fa13df5980c7c5039ff3c9402f16", null ],
    [ "UsbSpeedType", "group___u_s_b.html#gaec157a1e6a1f3481cc05d57bf83e343f", null ],
    [ "UsbId", "group___u_s_b.html#ga68f114dadab370b81c214c921a50ccd9", [
      [ "USB_ID_0", "group___u_s_b.html#gga68f114dadab370b81c214c921a50ccd9abd53f6c9ff17df32b9ca58f37f9dbd5c", null ],
      [ "USB_ID_MAX", "group___u_s_b.html#gga68f114dadab370b81c214c921a50ccd9af0ab9182bee80d4f4b43464b9857b572", null ]
    ] ],
    [ "UsbRole", "group___u_s_b.html#ga0917f81629dbbb76d23079e7edd2c02d", [
      [ "USB_ROLE_NONE", "group___u_s_b.html#gga0917f81629dbbb76d23079e7edd2c02da49162713154ec476ed2b97b3c537ae9f", null ],
      [ "USB_ROLE_HOST", "group___u_s_b.html#gga0917f81629dbbb76d23079e7edd2c02da857325044d6ddb3515332ae16cf441fc", null ],
      [ "USB_ROLE_DEVICE", "group___u_s_b.html#gga0917f81629dbbb76d23079e7edd2c02da2fa4715db7591ba61b7ee35f165de020", null ]
    ] ],
    [ "UsbSpeedType", "group___u_s_b.html#ga8f1e1d2a2339cf159bac3fb8eec07324", [
      [ "USB_SPEED_UNKNOWN", "group___u_s_b.html#gga8f1e1d2a2339cf159bac3fb8eec07324ac9755ae6b86f8148054fd6a342c74acc", null ],
      [ "USB_SPEED_LOW", "group___u_s_b.html#gga8f1e1d2a2339cf159bac3fb8eec07324a0ec4f8f66feaf7ee8f2ee618302e9470", null ],
      [ "USB_SPEED_FULL", "group___u_s_b.html#gga8f1e1d2a2339cf159bac3fb8eec07324a0f17d0b9928086c6114fea73e08f1780", null ],
      [ "USB_SPEED_HIGH", "group___u_s_b.html#gga8f1e1d2a2339cf159bac3fb8eec07324a57eeede6d769b09c01ac9c9c62fef8c9", null ]
    ] ],
    [ "hal_usb_add_device", "group___u_s_b.html#ga5a00d13920021b251b3d1aa8a4211663", null ],
    [ "hal_usb_deinit", "group___u_s_b.html#ga4424be9dad52f7e4fbe0f41a0d0f4c45", null ],
    [ "hal_usb_get_device", "group___u_s_b.html#ga682d24079212647c38030d2057f7784f", null ],
    [ "hal_usb_init", "group___u_s_b.html#ga8776403cbe7ab8c5e71a55eda7e631f5", null ],
    [ "hal_usb_irq_handler", "group___u_s_b.html#ga9e19bc794cd142bd95fdfa1f21c7f3cd", null ],
    [ "hal_usb_remove_device", "group___u_s_b.html#gad983b6788142da73aed5baa667b478e2", null ],
    [ "hal_usbd_process", "group___u_s_b.html#ga882c3fc3deac50a0fb83a2a0e7408524", null ],
    [ "hal_usbh_device_connect", "group___u_s_b.html#gaa4d3447040d7cb4ec24c8f0f1e77bb79", null ],
    [ "hal_usbh_enumerate", "group___u_s_b.html#gac907aa58c7469ed31f475ea2f7732417", null ],
    [ "hal_usbh_udisk_init", "group___u_s_b.html#gae0dbd544880a8e4f7a5cf04413566866", null ],
    [ "hal_usbh_udisk_ioctl", "group___u_s_b.html#ga37f886c93cb676735c2919f12cce4460", null ],
    [ "hal_usbh_udisk_read", "group___u_s_b.html#ga0afc0d3fedd6208e154bb4dec35d5cd9", null ],
    [ "hal_usbh_udisk_status", "group___u_s_b.html#ga615a42c6fc97215f21a61bbe4a52fae1", null ],
    [ "hal_usbh_udisk_write", "group___u_s_b.html#ga0aebbadd67e3bfec9fe5bd4493d2e1a5", null ]
];