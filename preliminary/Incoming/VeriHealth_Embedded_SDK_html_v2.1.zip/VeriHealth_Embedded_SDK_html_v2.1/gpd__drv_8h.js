var gpd__drv_8h =
[
    [ "vs_gpd_bin_ops", "group___d_r_v___p_o_w_e_r.html#ga9d571b89375740d1056464507c0966e3", null ],
    [ "vs_gpd_pcu_ctrl_ops", "group___d_r_v___p_o_w_e_r.html#gac40cf1cac68f75d821b3d4f495f5bdce", null ],
    [ "vs_gpd_ram_reten_ops", "group___d_r_v___p_o_w_e_r.html#ga804ec8ee03fa2270871404ff9cd6f285", null ]
];