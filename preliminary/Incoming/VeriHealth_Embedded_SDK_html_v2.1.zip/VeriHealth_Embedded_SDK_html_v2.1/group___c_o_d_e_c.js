var group___c_o_d_e_c =
[
    [ "CodecParams", "struct_codec_params.html", [
      [ "ch_num", "struct_codec_params.html#aa34a7abd6d66b1ae2075b175aa30811c", null ],
      [ "data_width", "struct_codec_params.html#a7db7a45faf03cf33c489b4bdc56520f1", null ],
      [ "fmt", "struct_codec_params.html#a5c18698faba83f4593b51eb3cf576068", null ],
      [ "sample_rate", "struct_codec_params.html#a27fba4196da94284bf1965afca34530c", null ],
      [ "sclk_rate", "struct_codec_params.html#a86acbd099db35607858ee60a735b6df1", null ]
    ] ],
    [ "CodecHWConfig", "struct_codec_h_w_config.html", [
      [ "id", "struct_codec_h_w_config.html#a2997d414c8d59123fd16ba41f0001c21", null ]
    ] ],
    [ "CodecDevice", "struct_codec_device.html", [
      [ "bus_cfg", "struct_codec_device.html#a50fc5929a75e94bbd9be1c02ffdb4f38", null ],
      [ "bus_dev", "struct_codec_device.html#ace4b7ca51c3670685ec1b05ced56d21a", null ],
      [ "hw_config", "struct_codec_device.html#ac58819c4e34eae538f9dfe99d7fbe896", null ],
      [ "ops", "struct_codec_device.html#a8b8657cc9d8258a99232e5ff8afea0bb", null ],
      [ "private_data", "struct_codec_device.html#a7bda96e3c674e0fb715db3a14998ac04", null ]
    ] ],
    [ "CodecOperation", "struct_codec_operation.html", [
      [ "close", "struct_codec_operation.html#ad9dd2061d2268af7970222575ae1d7c0", null ],
      [ "config", "struct_codec_operation.html#ad9874727773c51fbe980426242ac7fcf", null ],
      [ "mute", "struct_codec_operation.html#a0b049e3db179faf4becd02be4b4a83cf", null ],
      [ "set_gain", "struct_codec_operation.html#a0c9ef5f7122a543c7e5d55143a3c4030", null ]
    ] ],
    [ "ARRAY_SIZE", "group___c_o_d_e_c.html#ga25f003de16c08a4888b69f619d70f427", null ],
    [ "CODEC_PORT_MAX", "group___c_o_d_e_c.html#gad6fa55b36ab82007a32595b78b1c6843", null ],
    [ "CodecDef", "group___c_o_d_e_c.html#ga5585b51af62f770591bd2795172308d2", null ],
    [ "CodecDevice", "group___c_o_d_e_c.html#ga660b84065432febeda939c1999ed1cb5", null ],
    [ "CodecHWConfig", "group___c_o_d_e_c.html#gab15ffb50a737dc95782170a3d69934cb", null ],
    [ "CodecOperation", "group___c_o_d_e_c.html#gab1db9363d4c2022c4ee7ebc7e06e10dc", null ],
    [ "CodecParams", "group___c_o_d_e_c.html#gad72d9932c46db92fdd74fc911bcb8227", null ],
    [ "CodecDef", "group___c_o_d_e_c.html#ga197f7361a3dfe71098b812fe06ecc0f2", [
      [ "CODEC_ID_0", "group___c_o_d_e_c.html#gga197f7361a3dfe71098b812fe06ecc0f2af365b5238aff70babf5d6173c543419f", null ],
      [ "CODEC_ID_MAX", "group___c_o_d_e_c.html#gga197f7361a3dfe71098b812fe06ecc0f2a26aab8a953346520de780d93a6b8aa63", null ]
    ] ],
    [ "hal_codec_add_dev", "group___c_o_d_e_c.html#ga2ec189b3e17b0aaf41a8d356e80f20f3", null ],
    [ "hal_codec_close", "group___c_o_d_e_c.html#gaef7fc8d0e4428f5343d7fb1f4745c288", null ],
    [ "hal_codec_config", "group___c_o_d_e_c.html#ga3fcd25b223a89a248ec6604549539021", null ],
    [ "hal_codec_get_device", "group___c_o_d_e_c.html#gae2bf10b464730a46d0a5115652170e81", null ],
    [ "hal_codec_mute", "group___c_o_d_e_c.html#ga081a1068780b9b74b027477a0dc8a9e4", null ],
    [ "hal_codec_remove_dev", "group___c_o_d_e_c.html#gaf271b14fd0d911543da513890bcdf87a", null ],
    [ "hal_codec_set_gain", "group___c_o_d_e_c.html#ga83c2b05c2bbaeb4842baa986cdb27ed6", null ]
];