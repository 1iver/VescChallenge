var group___h_e_a_p =
[
    [ "osal_free", "group___h_e_a_p.html#gadebe46600cacff400434eec9a7e35845", null ],
    [ "osal_free_noncache", "group___h_e_a_p.html#ga3001b0df24d02e2ff98cafd23f02b406", null ],
    [ "osal_malloc", "group___h_e_a_p.html#gacdab8df33ecff4a9ff86ce7e05f2373d", null ],
    [ "osal_malloc_noncache", "group___h_e_a_p.html#ga721508f3b643e53587797eb556639620", null ]
];