var group___d_r_v___c_l_o_c_k =
[
    [ "ClkHwCfg", "struct_clk_hw_cfg.html", [
      [ "name", "struct_clk_hw_cfg.html#a780c16fff072b973a0fe3895e5d59385", null ],
      [ "type", "struct_clk_hw_cfg.html#a56897eeaaa9319e87326542bba4a40b4", null ]
    ] ],
    [ "ClkFuncs", "struct_clk_funcs.html", [
      [ "enable", "struct_clk_funcs.html#a54df22c7c9c7ca6fcdebe90dc3c6cf27", null ],
      [ "get_enable", "struct_clk_funcs.html#a298d432960f371699f76b82617abd2d8", null ],
      [ "get_parent", "struct_clk_funcs.html#a2bded8c63fdf10889ac819d1063452ce", null ],
      [ "init", "struct_clk_funcs.html#a5541526f47d04623a703eded550e29a4", null ],
      [ "recalc_rate", "struct_clk_funcs.html#a387099c9bfdf51d29e4fae6e1b8c396f", null ],
      [ "set_parent", "struct_clk_funcs.html#a156430238c1c1489a8ce2b970838948b", null ],
      [ "set_rate", "struct_clk_funcs.html#afbde85855b6c4c2e5ca0ed881e5c75e8", null ]
    ] ],
    [ "ClkFuncs", "group___d_r_v___c_l_o_c_k.html#ga133241a90f2d0eb25f04be15b2b1fe36", null ],
    [ "ClkHwCfg", "group___d_r_v___c_l_o_c_k.html#ga7073110c34a7b9858c7779a28138ef92", null ],
    [ "comp_funcs", "group___d_r_v___c_l_o_c_k.html#ga9ce76651083c27dea77564942ef98509", null ],
    [ "div_funcs", "group___d_r_v___c_l_o_c_k.html#gab1b7fd50085d01e7e09e251bd60e65c3", null ],
    [ "fix_div_funcs", "group___d_r_v___c_l_o_c_k.html#gab2527e98173f3b65e4d0615d0e44aee9", null ],
    [ "fix_funcs", "group___d_r_v___c_l_o_c_k.html#gaf12b85575aaf1ff98396a759d4226377", null ],
    [ "gate_funcs", "group___d_r_v___c_l_o_c_k.html#ga2420926b44924e15bc00e573a0a85fb6", null ],
    [ "mux_funcs", "group___d_r_v___c_l_o_c_k.html#ga83c1a3e79af0e34c388092977a30b981", null ],
    [ "pll_funcs", "group___d_r_v___c_l_o_c_k.html#ga7bd2bfbccab8c58e123a112e677cd02e", null ]
];