var group___e_v_e_n_t =
[
    [ "OsalEvent", "struct_osal_event.html", [
      [ "data", "struct_osal_event.html#abf3ac1c454370da3a32e8ffebd9d69c6", null ],
      [ "event_id", "struct_osal_event.html#a4a8b6d3131f37d5eb0d8f6d82e1de814", null ]
    ] ],
    [ "OsalEventEntry", "struct_osal_event_entry.html", [
      [ "event_data", "struct_osal_event_entry.html#a7b83fc215e0805042c9d4b71a7167630", null ],
      [ "event_entry", "struct_osal_event_entry.html#a02466d838772a2081d0da2d85151df4b", null ]
    ] ],
    [ "OsalEvent", "group___e_v_e_n_t.html#gac3bb1a8db08ea89cb9d7159905fb1017", null ],
    [ "OsalEventEntry", "group___e_v_e_n_t.html#gab2909b38a61f106b25438dc1af3e8f96", null ],
    [ "osal_create_event_queue", "group___e_v_e_n_t.html#gaa164bdab99aa02f9150e06efb6e5cbd6", null ],
    [ "osal_create_queue_raw", "group___e_v_e_n_t.html#ga8eddc41d5580f50a1589e05c6b74c7fd", null ],
    [ "osal_get_event_pool_length", "group___e_v_e_n_t.html#gae4d53b9f1c6460bde002c361221db38a", null ],
    [ "osal_send_event", "group___e_v_e_n_t.html#ga5500363395b62c736e86a73cda987b63", null ],
    [ "osal_send_event_raw", "group___e_v_e_n_t.html#ga3f4e6ce1e0d3a5f9f847859bde1a5819", null ],
    [ "osal_send_event_raw_from_isr", "group___e_v_e_n_t.html#gae478b79488e6c4606e7b7724a9902463", null ],
    [ "osal_wait_event", "group___e_v_e_n_t.html#ga27f60448f0195b8b84f527a589348a82", null ],
    [ "osal_wait_event_raw", "group___e_v_e_n_t.html#gadc0e4e7ae245da00136bc08c06145ce7", null ]
];