var group___b_o_a_r_d =
[
    [ "DEVICE", "group___d_e_v_i_c_e.html", "group___d_e_v_i_c_e" ],
    [ "BoardDevice", "struct_board_device.html", [
      [ "name", "struct_board_device.html#a7a21d8dcc31ce140da10e131122a3457", null ],
      [ "priv", "struct_board_device.html#a30695af3eaa1b01703ccd9722674d8c0", null ],
      [ "reserved", "struct_board_device.html#aaa5b1e83a37247e4c8ce7f9e5845900c", null ]
    ] ],
    [ "BoardOperations", "struct_board_operations.html", [
      [ "find_device", "struct_board_operations.html#a0ea5d603745b9bede6758c8374b798e2", null ],
      [ "get_wakeup_src", "struct_board_operations.html#a3ea9df41573f79a454b85a5a50f36b08", null ],
      [ "init", "struct_board_operations.html#a50574483707193b8c7505e9c6bff16b2", null ]
    ] ],
    [ "BoardDevice", "group___b_o_a_r_d.html#ga0ea66df699b2a9381e686f591cf028da", null ],
    [ "BoardOperations", "group___b_o_a_r_d.html#gabdbd851b07546735ebe150966327bf29", null ],
    [ "board_find_device_by_id", "group___b_o_a_r_d.html#gae5440b0202f28fe001798f210a4fa72b", null ],
    [ "board_get_ops", "group___b_o_a_r_d.html#ga66cc7b12ee37f4fed4072197e196e424", null ],
    [ "board_init", "group___b_o_a_r_d.html#ga52ed0dcd36a5a201ea9bca39379d9184", null ],
    [ "board_register", "group___b_o_a_r_d.html#ga66e722271be03b7832d3bcf181e8c090", null ],
    [ "get_wakeup_src", "group___b_o_a_r_d.html#gaa7d803a98004f5a8edd07cf7cfa10dae", null ]
];