var bsp__sysctl_8h =
[
    [ "bsp_ahb_clock_get_freq", "group___p_e_g_a_s_u_s.html#ga901094b1ad0d763ef2cfc8d489c29be0", null ],
    [ "bsp_apb_clock_get_freq", "group___p_e_g_a_s_u_s.html#gaffb8ef5e07fc072d8da58476b1a29f94", null ],
    [ "bsp_cpu_clock_get_freq", "group___p_e_g_a_s_u_s.html#gaf08467e85696be8ce178ca94c0c17982", null ],
    [ "bsp_disable_irq", "group___p_e_g_a_s_u_s.html#gaf35a5808978aaccd1d46ca8ce4b80dd4", null ],
    [ "bsp_enable_irq", "group___p_e_g_a_s_u_s.html#ga3b5611202e4221b7a6cb9aae142a6583", null ],
    [ "bsp_get_zsp_boot_status", "group___p_e_g_a_s_u_s.html#ga61dc26c192e2d7a02e012e74ac6b1f75", null ],
    [ "bsp_init", "group___p_e_g_a_s_u_s.html#gac1d41f544770121f1cb61aeb64e5807e", null ],
    [ "bsp_rtc_clock_get_freq", "group___p_e_g_a_s_u_s.html#ga95ead838aa92060f11197ca8108cfd11", null ],
    [ "bsp_sw_load_zsp", "group___p_e_g_a_s_u_s.html#ga97260869dbf3274fe93ae6fef3a19d11", null ],
    [ "bsp_sw_start_zsp", "group___p_e_g_a_s_u_s.html#gae2e384e7d3e7f3d0a33a8eba0ac8ac76", null ],
    [ "bsp_sw_stop_zsp", "group___p_e_g_a_s_u_s.html#gac074f43096cde2a280dca2292d8b7539", null ],
    [ "delay_ms", "group___p_e_g_a_s_u_s.html#gab7cce8122024d7ba47bf10f434956de4", null ],
    [ "delay_us", "group___p_e_g_a_s_u_s.html#gab33ebb2c5ca2d80d259c64a9d658589f", null ]
];