var arch__api_8h =
[
    [ "CpuSleepMode", "group___a_r_c_h.html#gaa5a47b2a7af78266e7e22897725dbbc1", null ],
    [ "CpuSleepMode", "group___a_r_c_h.html#ga8800d8a301fd21ea0b2d4d2bb81883dc", [
      [ "CPU_SLEEP_GENERAL", "group___a_r_c_h.html#gga8800d8a301fd21ea0b2d4d2bb81883dca95da74bd848a5dcd003a6d0f79695737", null ],
      [ "CPU_SLEEP_SHALLOW", "group___a_r_c_h.html#gga8800d8a301fd21ea0b2d4d2bb81883dca481b34604893702efeff01559bff9bab", null ],
      [ "CPU_SLEEP_DEEP", "group___a_r_c_h.html#gga8800d8a301fd21ea0b2d4d2bb81883dca65f76739023c249f05134ea0dcab69cc", null ]
    ] ],
    [ "cpu_disable_interrupts", "group___a_r_c_h.html#ga1f3ae9aa674e5b660124c7e9fad54928", null ],
    [ "cpu_halt", "group___a_r_c_h.html#ga3758ebe4104e2a5b823470729c7dfdcc", null ],
    [ "cpu_idle", "group___a_r_c_h.html#ga51e9575fc9ce151b38534af107ec38cb", null ],
    [ "cpu_set_isr_priority", "group___a_r_c_h.html#ga8b084305f1f999f207662358cd84ff90", null ],
    [ "cpu_sleep", "group___a_r_c_h.html#gab04bfbdfdfc9c835c6026b8ae6daac08", null ]
];