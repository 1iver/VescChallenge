var group___b_s_p =
[
    [ "ARCH", "group___a_r_c_h.html", "group___a_r_c_h" ],
    [ "BOARD", "group___b_o_a_r_d.html", "group___b_o_a_r_d" ],
    [ "SOC", "group___s_o_c.html", "group___s_o_c" ],
    [ "bsp_init", "group___b_s_p.html#gac1d41f544770121f1cb61aeb64e5807e", null ]
];