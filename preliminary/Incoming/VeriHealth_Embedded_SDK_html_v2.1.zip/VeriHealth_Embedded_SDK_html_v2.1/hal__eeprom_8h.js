var hal__eeprom_8h =
[
    [ "EepromDevice", "group___e_e_p_r_o_m.html#ga44f301824c2cf7bec9f585a085b26207", null ],
    [ "EEPROMIdDef", "group___e_e_p_r_o_m.html#ga39c726d0e65098a10212e45611b3eb60", null ],
    [ "EepromInfo", "group___e_e_p_r_o_m.html#gafb4e0202b8424124eb9a14caa486f716", null ],
    [ "EepromOperations", "group___e_e_p_r_o_m.html#ga8ac67c8a339664caaeb5317faed51b3e", null ],
    [ "EepromIdDef", "group___e_e_p_r_o_m.html#gafce0e686ea8928f5610645da5fdb1685", [
      [ "EEPROM_ID_0", "group___e_e_p_r_o_m.html#ggafce0e686ea8928f5610645da5fdb1685a0d215152fdd245dd625e8875dab90adf", null ],
      [ "EEPROM_ID_1", "group___e_e_p_r_o_m.html#ggafce0e686ea8928f5610645da5fdb1685aedd7edfe7e8dc01d62297fb8fe8842bf", null ],
      [ "EEPROM_ID_2", "group___e_e_p_r_o_m.html#ggafce0e686ea8928f5610645da5fdb1685aeb266d45a23866ac178b96a08dbe4a80", null ],
      [ "EEPROM_ID_3", "group___e_e_p_r_o_m.html#ggafce0e686ea8928f5610645da5fdb1685afa3d9d3c726cb262423aa5067aeb90d0", null ],
      [ "EEPROM_ID_MAX", "group___e_e_p_r_o_m.html#ggafce0e686ea8928f5610645da5fdb1685adba7e23526f409705a1a3e6246a7e526", null ]
    ] ],
    [ "hal_eeprom_add_dev", "group___e_e_p_r_o_m.html#ga1a3094925f43db56c46023782093cf1c", null ],
    [ "hal_eeprom_get_device", "group___e_e_p_r_o_m.html#ga62babe7483310001b5de9914cf52dd8f", null ],
    [ "hal_eeprom_read", "group___e_e_p_r_o_m.html#ga2fe90a4d34df60f75effb1f633cf9cd1", null ],
    [ "hal_eeprom_write", "group___e_e_p_r_o_m.html#ga35a438258ae6a106123cf95e5098bb57", null ]
];