var group___t_a_s_k =
[
    [ "osal_enter_critical", "group___t_a_s_k.html#ga4cb1022e530241f521e6a36f04e62613", null ],
    [ "osal_exit_critical", "group___t_a_s_k.html#gaf770e47fd21e2cd9a9b7041b79b36cc5", null ],
    [ "OSAL_TASK_PRI_HIGHEST", "group___t_a_s_k.html#ga7c0d3abdca716b7a77a273e20d276f33", null ],
    [ "osal_create_task", "group___t_a_s_k.html#ga4566494220689665feb5af782d5f0245", null ],
    [ "osal_delete_task", "group___t_a_s_k.html#gab946a791659a4618c87147fc93f85abe", null ],
    [ "osal_end_scheduler", "group___t_a_s_k.html#ga92cb79a5ed4d2da850524053fcfe214a", null ],
    [ "osal_resume_all", "group___t_a_s_k.html#gaff781ef8a068d9e3a446083bb8f59613", null ],
    [ "osal_sleep", "group___t_a_s_k.html#gaaca082fb52a2e73a0e63d7affe8bf126", null ],
    [ "osal_start_scheduler", "group___t_a_s_k.html#ga66a1e4d1d3551c061fd734f324b51d3a", null ],
    [ "osal_started", "group___t_a_s_k.html#ga77110758da8ab742db3a096306434e24", null ],
    [ "osal_suspend_all", "group___t_a_s_k.html#gab15668291790e0f099257558d1cda2b1", null ]
];