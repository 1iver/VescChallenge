var hal__codec_8h =
[
    [ "ARRAY_SIZE", "group___c_o_d_e_c.html#ga25f003de16c08a4888b69f619d70f427", null ],
    [ "CODEC_PORT_MAX", "group___c_o_d_e_c.html#gad6fa55b36ab82007a32595b78b1c6843", null ],
    [ "CodecDef", "group___c_o_d_e_c.html#ga5585b51af62f770591bd2795172308d2", null ],
    [ "CodecDevice", "group___c_o_d_e_c.html#ga660b84065432febeda939c1999ed1cb5", null ],
    [ "CodecHWConfig", "group___c_o_d_e_c.html#gab15ffb50a737dc95782170a3d69934cb", null ],
    [ "CodecOperation", "group___c_o_d_e_c.html#gab1db9363d4c2022c4ee7ebc7e06e10dc", null ],
    [ "CodecParams", "group___c_o_d_e_c.html#gad72d9932c46db92fdd74fc911bcb8227", null ],
    [ "CodecDef", "group___c_o_d_e_c.html#ga197f7361a3dfe71098b812fe06ecc0f2", [
      [ "CODEC_ID_0", "group___c_o_d_e_c.html#gga197f7361a3dfe71098b812fe06ecc0f2af365b5238aff70babf5d6173c543419f", null ],
      [ "CODEC_ID_MAX", "group___c_o_d_e_c.html#gga197f7361a3dfe71098b812fe06ecc0f2a26aab8a953346520de780d93a6b8aa63", null ]
    ] ],
    [ "hal_codec_add_dev", "group___c_o_d_e_c.html#ga2ec189b3e17b0aaf41a8d356e80f20f3", null ],
    [ "hal_codec_close", "group___c_o_d_e_c.html#gaef7fc8d0e4428f5343d7fb1f4745c288", null ],
    [ "hal_codec_config", "group___c_o_d_e_c.html#ga3fcd25b223a89a248ec6604549539021", null ],
    [ "hal_codec_get_device", "group___c_o_d_e_c.html#gae2bf10b464730a46d0a5115652170e81", null ],
    [ "hal_codec_mute", "group___c_o_d_e_c.html#ga081a1068780b9b74b027477a0dc8a9e4", null ],
    [ "hal_codec_remove_dev", "group___c_o_d_e_c.html#gaf271b14fd0d911543da513890bcdf87a", null ],
    [ "hal_codec_set_gain", "group___c_o_d_e_c.html#ga83c2b05c2bbaeb4842baa986cdb27ed6", null ]
];