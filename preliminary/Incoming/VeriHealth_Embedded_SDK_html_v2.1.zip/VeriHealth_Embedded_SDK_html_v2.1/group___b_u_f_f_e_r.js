var group___b_u_f_f_e_r =
[
    [ "RingBufCtrl", "struct_ring_buf_ctrl.html", [
      [ "buf", "struct_ring_buf_ctrl.html#ace84efad87f6b6bd4c1f9eabbc4fd582", null ],
      [ "capacity", "struct_ring_buf_ctrl.html#aed405a7d71a5551a8af6bc11d59e968d", null ],
      [ "continue_addr", "struct_ring_buf_ctrl.html#a617fd4d36efd4c9971ad7e12f3f95dbf", null ],
      [ "linear_capacity", "struct_ring_buf_ctrl.html#aa30b7981e946312731404e5d3c2c5dd1", null ],
      [ "rd_idx", "struct_ring_buf_ctrl.html#a7a1826f18b2c490e5905d356217654cc", null ],
      [ "wt_idx", "struct_ring_buf_ctrl.html#a30d3dec09df3ef7238b66552e2a4f72f", null ]
    ] ],
    [ "RingBufCtrl", "group___b_u_f_f_e_r.html#gaf82d63fbf9b0596790c9e730092a7529", null ],
    [ "RingBufInsertHandler", "group___b_u_f_f_e_r.html#gaa7de93e957f659ee5bb7f7d1f7628b81", null ],
    [ "vpi_ringbuf_delete", "group___b_u_f_f_e_r.html#ga8f29a0416af0e1d8294969f7f8d2ac19", null ],
    [ "vpi_ringbuf_flush", "group___b_u_f_f_e_r.html#ga025a148b496ac4f67069efbeb7af49ee", null ],
    [ "vpi_ringbuf_get_free_space", "group___b_u_f_f_e_r.html#ga369cd74b20098dcb4ae0b9323d541ece", null ],
    [ "vpi_ringbuf_get_used_space", "group___b_u_f_f_e_r.html#ga208a6ef6b8ee6b9165d7736e90e0066e", null ],
    [ "vpi_ringbuf_init", "group___b_u_f_f_e_r.html#ga8623d5b5d46b998e339a7a5bc4b68e52", null ],
    [ "vpi_ringbuf_insert", "group___b_u_f_f_e_r.html#ga99cf4c1cf02681c13d980d44f99437ed", null ],
    [ "vpi_ringbuf_peek", "group___b_u_f_f_e_r.html#ga5737c8f398d2f65d295ff237589b63fc", null ],
    [ "vpi_ringbuf_pop", "group___b_u_f_f_e_r.html#gaa087d5a685fdb66cf1d97fbbd41666b1", null ],
    [ "vpi_ringbuf_push", "group___b_u_f_f_e_r.html#ga550ee92e47c0a841103b9e66acc64f11", null ]
];