var group___v_d_t =
[
    [ "VdtHwConfig", "struct_vdt_hw_config.html", [
      [ "base", "struct_vdt_hw_config.html#af9ca457aae45f25ffe69808e30f86452", null ],
      [ "clk_id", "struct_vdt_hw_config.html#a0687837e541f54a95434ed11a44ca62c", null ],
      [ "irq_id", "struct_vdt_hw_config.html#a989bca821aa52c5602caace14b253b74", null ]
    ] ],
    [ "VdtDevice", "struct_vdt_device.html", [
      [ "ctx", "struct_vdt_device.html#a8d9535a39ce5da2341ea2f65501139d0", null ],
      [ "hw_config", "struct_vdt_device.html#a5f97a12b35e262004c16557f128db036", null ],
      [ "hw_id", "struct_vdt_device.html#a7bfb1ae5417953da764c38c810f98242", null ],
      [ "ops", "struct_vdt_device.html#a8d1f7614e0b18f20b0b7399c43413202", null ]
    ] ],
    [ "VdtOperations", "struct_vdt_operations.html", [
      [ "irq_handler", "struct_vdt_operations.html#afbb0f67d1247166fcb99b6fc30d8e153", null ],
      [ "power_ctrl", "struct_vdt_operations.html#ab434322e0b8b5e08c1e824125913f297", null ],
      [ "set_callback", "struct_vdt_operations.html#a5bda88603f3a9d2c0dbb7d91f9d4f08f", null ],
      [ "set_mode", "struct_vdt_operations.html#ab9eb660fd4951b13bd2c3f7c4c310200", null ],
      [ "trigger_work_mode", "struct_vdt_operations.html#a38e6676b60ff4f827395cd8b7bfe3811", null ]
    ] ],
    [ "VDT_ID_0", "group___v_d_t.html#gae872308b8af042f427eda322e010b2fa", null ],
    [ "VDT_MAX_DEVICE", "group___v_d_t.html#ga36622593e878db8b4b18d7ba70e84ea3", null ],
    [ "VdtCallback", "group___v_d_t.html#gae1f11326a168f266776bf112cdf524cf", null ],
    [ "VdtDevice", "group___v_d_t.html#ga36f95e4257ed705e6f44e213fd46dffc", null ],
    [ "VdtHwConfig", "group___v_d_t.html#gad45102e13fe6d4950df0927609f8bd0c", null ],
    [ "VdtOperations", "group___v_d_t.html#ga9dbfc000df3743d23f0cacecd8d56a45", null ],
    [ "hal_vdt_add_device", "group___v_d_t.html#gaf76ca62acca1e0d226ae97fbf5406c0f", null ],
    [ "hal_vdt_get_device", "group___v_d_t.html#ga7bc56b6ead180533e178e1e5a1ccab56", null ],
    [ "hal_vdt_irq_handler", "group___v_d_t.html#ga120db992250d5e5d4161c83c12951d0d", null ],
    [ "hal_vdt_power_ctrl", "group___v_d_t.html#ga3edc8277dbda315d02dad44f2fab18c1", null ],
    [ "hal_vdt_remove_device", "group___v_d_t.html#ga570b5ad6b563f4781c7e1e1976efa9ce", null ],
    [ "hal_vdt_set_callback", "group___v_d_t.html#ga7ef7d7489bc8e1135379243ba20a949c", null ],
    [ "hal_vdt_set_mode", "group___v_d_t.html#ga3e7c123896c5522cb6761f008a3e5829", null ],
    [ "hal_vdt_trigger_work_mode", "group___v_d_t.html#gab827477d2325d6240482e7959651f196", null ]
];