var group___o_s_a_l =
[
    [ "TIME", "group___t_i_m_e.html", "group___t_i_m_e" ],
    [ "TASK", "group___t_a_s_k.html", "group___t_a_s_k" ],
    [ "NOTIFY", "group___n_o_t_i_f_y.html", "group___n_o_t_i_f_y" ],
    [ "SEMAPHORE", "group___s_e_m_a_p_h_o_r_e.html", "group___s_e_m_a_p_h_o_r_e" ],
    [ "LOCK", "group___l_o_c_k.html", "group___l_o_c_k" ],
    [ "COMMON", "group___c_o_m_m_o_n.html", "group___c_o_m_m_o_n" ],
    [ "EVENT", "group___e_v_e_n_t.html", "group___e_v_e_n_t" ],
    [ "HEAP", "group___h_e_a_p.html", "group___h_e_a_p" ],
    [ "STATE", "group___s_t_a_t_e.html", "group___s_t_a_t_e" ]
];