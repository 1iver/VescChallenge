var hal__crypto_8h =
[
    [ "CRYPTO_CAP_BLKCIPHER", "group___c_r_y_p_t_o.html#ga90f046b5bfec0a7321c47aaa455026fd", null ],
    [ "CRYPTO_CAP_ECC", "group___c_r_y_p_t_o.html#ga32efb7331b0f41d9f9b49f673d416b03", null ],
    [ "CRYPTO_CAP_HASH", "group___c_r_y_p_t_o.html#ga7cadb64b11f455f76aa656e14ef17646", null ],
    [ "CRYPTO_CAP_MAC", "group___c_r_y_p_t_o.html#gaa4419418ad6a08d0f78bd0f31f6d3edf", null ],
    [ "CRYPTO_CAP_RSA", "group___c_r_y_p_t_o.html#gac2f84e24c9cc889747e4ed758396dc66", null ],
    [ "CRYPTO_CAP_SRP", "group___c_r_y_p_t_o.html#gafc8cb12f398e4d9137c1bb33be78dc41", null ],
    [ "CRYPTO_CAP_TRNG", "group___c_r_y_p_t_o.html#gabd8bc2d7c99a4a03a4ddb68431cab24c", null ],
    [ "CRYPTO_MAX_CAP", "group___c_r_y_p_t_o.html#gaa7c7547377d0c43d26ada1acddc5bf9e", null ],
    [ "CRYPTO_MAX_DEVICE", "group___c_r_y_p_t_o.html#ga242408db2550eea69b4367cd8d205c6c", null ],
    [ "CryptoData", "group___c_r_y_p_t_o.html#ga9bf99e222a7f2968fc01317e4f69f91d", null ],
    [ "CryptoDevice", "group___c_r_y_p_t_o.html#ga874255caa4daee8f627d61f0faa4df65", null ],
    [ "CryptoDevProp", "group___c_r_y_p_t_o.html#gaffd99abb78c13b2b47cdbbe037e4ccfe", null ],
    [ "CryptoHwConfig", "group___c_r_y_p_t_o.html#gac223ff4e2c731aaac636274827ba0d64", null ],
    [ "CryptoId", "group___c_r_y_p_t_o.html#ga2aa3f44f7ac3c9e19b6bac32c8092c21", null ],
    [ "CryptoOperations", "group___c_r_y_p_t_o.html#gac7fcc0a5e5a3a4baf0296d493f59f9c4", null ],
    [ "CryptoOps", "group___c_r_y_p_t_o.html#ga23c7ce949cdc62a1ae87f9f62196e573", null ],
    [ "CryptoParams", "group___c_r_y_p_t_o.html#gaf7213e10c813c46b8a8adee2e68fe238", null ],
    [ "CryptoDevProp", "group___c_r_y_p_t_o.html#ga808ad9db37c915a88c43fe4bebf119a6", [
      [ "CRYPTO_DEV_PROP_HW", "group___c_r_y_p_t_o.html#gga808ad9db37c915a88c43fe4bebf119a6a213f07c886cadb186f892774024fd4fe", null ],
      [ "CRYPTO_DEV_PROP_SW", "group___c_r_y_p_t_o.html#gga808ad9db37c915a88c43fe4bebf119a6a64180cc9579870bf3eb20265246547a7", null ]
    ] ],
    [ "CryptoId", "group___c_r_y_p_t_o.html#gad4aef0363215bf6934a9d57f38fa54fc", [
      [ "CRYPTO_ID_0", "group___c_r_y_p_t_o.html#ggad4aef0363215bf6934a9d57f38fa54fca0f1dce11b6f7d34b4b36011d45fd28dd", null ],
      [ "CRYPTO_ID_1", "group___c_r_y_p_t_o.html#ggad4aef0363215bf6934a9d57f38fa54fcae8f166ab0a4f610e47e1705ea0ed49a0", null ]
    ] ],
    [ "hal_crypto_add_device", "group___c_r_y_p_t_o.html#ga94bcced092f8299f4b324ed362dbb454", null ],
    [ "hal_crypto_blkcipher", "group___c_r_y_p_t_o.html#gade8507687332993669d8964847c8c13f", null ],
    [ "hal_crypto_ecc", "group___c_r_y_p_t_o.html#gae23a0e17d882cb1d93b3207b772f61f3", null ],
    [ "hal_crypto_get_device", "group___c_r_y_p_t_o.html#gaacb9735a67c0ff8f884e84564e2a8d2c", null ],
    [ "hal_crypto_hash", "group___c_r_y_p_t_o.html#gae9a5cd64901470ac905a361fafd4bac1", null ],
    [ "hal_crypto_irq_handler", "group___c_r_y_p_t_o.html#ga34b88881aeff6de5ab16ddd5fb158d19", null ],
    [ "hal_crypto_mac", "group___c_r_y_p_t_o.html#ga348a7efaa96226341f79f310f942d0b4", null ],
    [ "hal_crypto_remove_device", "group___c_r_y_p_t_o.html#gaf2afd8ea7938cefcbfa0c8edf892f8d3", null ],
    [ "hal_crypto_reset", "group___c_r_y_p_t_o.html#ga108c5550a00327ecfb26b78c835690b4", null ],
    [ "hal_crypto_rsa", "group___c_r_y_p_t_o.html#ga314f448116d3132ed18e2da28fbfb85d", null ],
    [ "hal_crypto_srp", "group___c_r_y_p_t_o.html#ga449b0197f2f2280bbde7cbd707099896", null ],
    [ "hal_crypto_start", "group___c_r_y_p_t_o.html#ga3460e6498c86c114cd6d7101c9bd9064", null ],
    [ "hal_crypto_stop", "group___c_r_y_p_t_o.html#ga6927e6b8088f9bef8886cf1c40621bfa", null ],
    [ "hal_crypto_trng", "group___c_r_y_p_t_o.html#ga17a99ede292586b869887aa781a2a0f0", null ]
];