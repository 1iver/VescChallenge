var group___l_o_c_k =
[
    [ "OsalMutex", "struct_osal_mutex.html", [
      [ "mutex", "struct_osal_mutex.html#aaa3e3ad39e88bfe7724108cb0576acc6", null ],
      [ "mutex", "struct_osal_mutex.html#ad700d158c78b1f3f1a25e3695904f3f3", null ]
    ] ],
    [ "OsalMutex", "group___l_o_c_k.html#gaf8a6faddf39b252e36bc1c7d88f8055c", null ],
    [ "osal_init_mutex", "group___l_o_c_k.html#ga67cddaac393682f05a08bf9e26a6a31e", null ],
    [ "osal_lock_mutex", "group___l_o_c_k.html#ga3b426c9696d0fec59e5886c19a786ec5", null ],
    [ "osal_unlock_mutex", "group___l_o_c_k.html#ga692676865b1a4021168e615747000321", null ]
];