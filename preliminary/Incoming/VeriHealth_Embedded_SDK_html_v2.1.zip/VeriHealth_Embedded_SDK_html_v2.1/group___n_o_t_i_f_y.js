var group___n_o_t_i_f_y =
[
    [ "OsalNotify", "struct_osal_notify.html", [
      [ "action", "struct_osal_notify.html#af93fbe0187af7cdb2ab0e9752e715cdd", null ],
      [ "higher_task_woken", "struct_osal_notify.html#a8379a53cca2ca238f27fa05595011130", null ],
      [ "index_to_notify", "struct_osal_notify.html#ae2f8c62247320692e18213c8b52a7324", null ],
      [ "notify_value", "struct_osal_notify.html#a64078872a932ba254329dd17b44e3771", null ],
      [ "pre_ntfy_val", "struct_osal_notify.html#a64e3c2163966dbe21628790948421da7", null ],
      [ "task_to_notify", "struct_osal_notify.html#a769a67ed770cc0f4097016554cb0fb9a", null ]
    ] ],
    [ "OsalNotifyWait", "struct_osal_notify_wait.html", [
      [ "bits_to_clr_on_in", "struct_osal_notify_wait.html#ae0580f1ff7f9d6686fd0be676511aaa6", null ],
      [ "bits_to_clr_on_out", "struct_osal_notify_wait.html#a66bc2cbf43a3b46d7eba98499f2ad675", null ],
      [ "index_to_wait", "struct_osal_notify_wait.html#a1006dbe649dfad753ab5833fefce163c", null ],
      [ "notify_value", "struct_osal_notify_wait.html#ae8ed0d86c359ca32681e7d9fedd9773c", null ],
      [ "ticks_to_wait", "struct_osal_notify_wait.html#a1b42bd99780ba481aab7343d6c8e4a7c", null ]
    ] ],
    [ "OsalNotify", "group___n_o_t_i_f_y.html#gacd44c52e9bd040d1fc56e92fb2615834", null ],
    [ "OsalNotifyWait", "group___n_o_t_i_f_y.html#ga7114eddd3bbe7f9ac8fddc1d264d4c17", null ],
    [ "osal_task_notify", "group___n_o_t_i_f_y.html#ga560879b0e07e262f170ecf03081a8031", null ],
    [ "osal_task_notify_from_isr", "group___n_o_t_i_f_y.html#ga331a529194d2c03d8037d40c842b48dc", null ],
    [ "osal_task_notify_wait", "group___n_o_t_i_f_y.html#gad43a9f41afb3fd8348abb2b8f9f05c45", null ]
];