var group__bluetooth =
[
    [ "Device Address", "group__bt__addr.html", "group__bt__addr" ],
    [ "Attribute Protocol (ATT)", "group__bt__att.html", "group__bt__att" ],
    [ "Generic Access Profile", "group__bt__gap.html", "group__bt__gap" ],
    [ "Connection management", "group__bt__conn.html", "group__bt__conn" ],
    [ "Cryptography", "group__bt__crypto.html", "group__bt__crypto" ],
    [ "Defines and Assigned Numbers", "group__bt__gap__defines.html", "group__bt__gap__defines" ],
    [ "Generic Attribute Profile (GATT)", "group__bt__gatt.html", "group__bt__gatt" ],
    [ "ISO", "group__bt__iso.html", "group__bt__iso" ],
    [ "UUIDs", "group__bt__uuid.html", "group__bt__uuid" ]
];