var group___f_i_f_o =
[
    [ "FifoCtrl", "struct_fifo_ctrl.html", [
      [ "buffer", "struct_fifo_ctrl.html#af138e3694ee260f8c6313a454730217f", null ],
      [ "buffer_size", "struct_fifo_ctrl.html#a9bcf7e5865c29ca53ed792c1585a366e", null ],
      [ "item_size", "struct_fifo_ctrl.html#a681aefcbd1f442374cbb163ecd0d6e96", null ],
      [ "item_stored", "struct_fifo_ctrl.html#af8e29c1fbbc22fa55667fd907a0ffe28", null ],
      [ "item_total", "struct_fifo_ctrl.html#a947b609e272831f75fbed44ba7a76bd9", null ],
      [ "rd_idx", "struct_fifo_ctrl.html#a76310f3034954828e19420d27a8a4c22", null ],
      [ "wt_idx", "struct_fifo_ctrl.html#af4d30f383a236f3bd36200c485e9ef6d", null ]
    ] ],
    [ "FifoInitData", "struct_fifo_init_data.html", [
      [ "buffer_addr", "struct_fifo_init_data.html#a28c51b7904aa2136a5345779eb0d70e5", null ],
      [ "buffer_size", "struct_fifo_init_data.html#a55edc67276bf1112f0cacd4183b7214b", null ],
      [ "item_size", "struct_fifo_init_data.html#a90c00c4193faeb9e7a8b722cad4b3ef5", null ],
      [ "item_total", "struct_fifo_init_data.html#a308ff07f2bb71968791af8855c8b0f7c", null ]
    ] ],
    [ "FifoAddHandler", "group___f_i_f_o.html#ga9766a59f65e353a7f566fbb533524742", null ],
    [ "FifoCtrl", "group___f_i_f_o.html#gad437d0d82b6fe19fbf15fe9f35f267a0", null ],
    [ "FifoInitData", "group___f_i_f_o.html#ga62afdff1b607d68ac170446fd40da0c4", null ],
    [ "vpi_fifo_add", "group___f_i_f_o.html#ga2b080e2d9979b127ee5d30e27dd8dcb6", null ],
    [ "vpi_fifo_flush", "group___f_i_f_o.html#gad12f4d9b8accff599724b3b1b343eb48", null ],
    [ "vpi_fifo_get", "group___f_i_f_o.html#gac79915fb01cc1ff7c07d3fc7fdce0517", null ],
    [ "vpi_fifo_get_stored_item", "group___f_i_f_o.html#gacbac2f6f63663cab05516bccbddd6331", null ],
    [ "vpi_fifo_init", "group___f_i_f_o.html#gafdce14a675ddaf044b794384d404f844", null ],
    [ "vpi_fifo_is_empty", "group___f_i_f_o.html#gab7779f4e3e6159540bd949f0ac530623", null ],
    [ "vpi_fifo_is_full", "group___f_i_f_o.html#gaa22c386eb92aecf2dd2718c65b43b243", null ],
    [ "vpi_fifo_peek", "group___f_i_f_o.html#ga1b410556768e8c23d33475dc2c1a672b", null ],
    [ "vpi_fifo_read", "group___f_i_f_o.html#ga65ba0160fac9920ae04f143849af45d1", null ],
    [ "vpi_fifo_static_init", "group___f_i_f_o.html#ga8ca6060907a31ca664da73cd27df8078", null ],
    [ "vpi_fifo_write", "group___f_i_f_o.html#ga08a98d890b22e0a4dc698b3b07fecc72", null ]
];