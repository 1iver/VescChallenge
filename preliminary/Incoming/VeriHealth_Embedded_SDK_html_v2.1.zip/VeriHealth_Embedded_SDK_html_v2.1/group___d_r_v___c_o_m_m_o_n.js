var group___d_r_v___c_o_m_m_o_n =
[
    [ "BusDevice", "struct_bus_device.html", [
      [ "i2c", "struct_bus_device.html#a27363d4ca3ff7d749fe8ae5b51d6db88", null ],
      [ "i3c", "struct_bus_device.html#a20fead1c3a757e9b7062cbb0a7864dc4", null ],
      [ "port_id", "struct_bus_device.html#a805f7d813b6f243fdaa2dab1cba030bd", null ],
      [ "spi", "struct_bus_device.html#a59a4972c6f22494e5ea0a7385a9d1b03", null ],
      [ "type", "struct_bus_device.html#a32375f407db5a2689e5115483b88cfb5", null ]
    ] ],
    [ "BusConfig", "union_bus_config.html", [
      [ "i2c", "union_bus_config.html#aa6e1cc40adc5126e8082b2af51fd0a16", null ],
      [ "i3c", "union_bus_config.html#ae7e464229616cd4136127c60f0e636a5", null ],
      [ "spi", "union_bus_config.html#a7d6331d002d7ad732d9e3a4d260d8dee", null ]
    ] ],
    [ "BIT", "group___d_r_v___c_o_m_m_o_n.html#ga4eaf4bf81c52c3f375967906e4d5ba17", null ],
    [ "container_of", "group___d_r_v___c_o_m_m_o_n.html#gaf8c317a42292b61c93aae91e59118a46", null ],
    [ "DIV_ROUND_UP", "group___d_r_v___c_o_m_m_o_n.html#gae664e7492e37d324831caf2321ddda37", null ],
    [ "GENMASK", "group___d_r_v___c_o_m_m_o_n.html#ga58530d20924859d16358c7400c37738d", null ],
    [ "MAX", "group___d_r_v___c_o_m_m_o_n.html#gafa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MIN", "group___d_r_v___c_o_m_m_o_n.html#ga3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "ROUND_DOWN", "group___d_r_v___c_o_m_m_o_n.html#gac387301961fe5833b6739f558239932e", null ],
    [ "BusConfig", "group___d_r_v___c_o_m_m_o_n.html#ga1b5d0c754c88729e9790c92c03223674", null ],
    [ "BusDevice", "group___d_r_v___c_o_m_m_o_n.html#ga08783c1fae8409f57d5948cf82637643", null ],
    [ "BusType", "group___d_r_v___c_o_m_m_o_n.html#ga5e19c75c2809d2f27eb33a29d1971b46", [
      [ "BUS_TYPE_I2C", "group___d_r_v___c_o_m_m_o_n.html#gga5e19c75c2809d2f27eb33a29d1971b46aaacfb33399af990fdd94d559ec501d91", null ],
      [ "BUS_TYPE_SPI", "group___d_r_v___c_o_m_m_o_n.html#gga5e19c75c2809d2f27eb33a29d1971b46a00179b782d9343b4a019f0c4fd81eedd", null ],
      [ "BUS_TYPE_I3C", "group___d_r_v___c_o_m_m_o_n.html#gga5e19c75c2809d2f27eb33a29d1971b46ab2168a3ab9d5d78feb679af49e6c5760", null ],
      [ "BYS_TYPE_MAX", "group___d_r_v___c_o_m_m_o_n.html#gga5e19c75c2809d2f27eb33a29d1971b46a415e9eabfca52ecf521ee11d89cdb0c7", null ]
    ] ],
    [ "__ffs", "group___d_r_v___c_o_m_m_o_n.html#ga72fde97d856a273ef86960a453e9ef38", null ],
    [ "vs_log2", "group___d_r_v___c_o_m_m_o_n.html#ga126dc772fff133ca14459d3d64c3467f", null ]
];