var group___c_l_o_c_k =
[
    [ "ClkHw", "struct_clk_hw.html", [
      [ "config", "struct_clk_hw.html#a7be56399676a598990a0ff39ed5e3e2c", null ],
      [ "funcs", "struct_clk_hw.html#abfbdc5e7ca6b22688bb434d9e51f9b8a", null ]
    ] ],
    [ "CLK_INVALID", "group___c_l_o_c_k.html#gaecab067c2ee01a6de471b14294f47c54", null ],
    [ "CLK_ROOT", "group___c_l_o_c_k.html#ga599f719e18f257d83b1c57e78d3ec666", null ],
    [ "ClkHw", "group___c_l_o_c_k.html#ga7ea9e4ba23312616ea982bb897b1ecb5", null ],
    [ "ClkType", "group___c_l_o_c_k.html#ga7abf0c2fdb50df2f3eb821479de4d9a7", [
      [ "CLK_TYPE_FIX", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7ab83c09fbe9d081fa1dda532a119a271d", null ],
      [ "CLK_TYPE_GATE", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7abc87bc9f34e1ac247cae5bdefca0cf7e", null ],
      [ "CLK_TYPE_DIV", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7a74b0dc503849f8cf4a81c7a75328da16", null ],
      [ "CLK_TYPE_FIX_DIV", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7a46d89cbc621215c36ce160b67aefc41c", null ],
      [ "CLK_TYPE_MUX", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7ab6f346ff9e39cbcc8ac17d45de200ada", null ],
      [ "CLK_TYPE_COMP", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7ae74712d0308d42e7cbe63d0e7049badf", null ],
      [ "CLK_TYPE_PLL", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7a70059a4618d39d345ebdd973d7c1e230", null ],
      [ "CLK_TYPE_COUNT", "group___c_l_o_c_k.html#gga7abf0c2fdb50df2f3eb821479de4d9a7a47672b8dc0c4fe5e4fb76b8ad6afb288", null ]
    ] ],
    [ "hal_clk_enable", "group___c_l_o_c_k.html#gadd412fc73ae08d2868476a231781fd92", null ],
    [ "hal_clk_get_enable", "group___c_l_o_c_k.html#ga8d209ea18ba16db16f950da187a696d6", null ],
    [ "hal_clk_get_parent", "group___c_l_o_c_k.html#ga60aaf41f766a629a9c810abf19a93b1a", null ],
    [ "hal_clk_init", "group___c_l_o_c_k.html#ga78a1ad86b8327cf3f64740acab24904d", null ],
    [ "hal_clk_recalc_rate", "group___c_l_o_c_k.html#ga7004c6eb52a79c1ca4252601deb1743f", null ],
    [ "hal_clk_set_parent", "group___c_l_o_c_k.html#ga73b6327e3c9aec2eb3915210aa9c617b", null ],
    [ "hal_clk_set_rate", "group___c_l_o_c_k.html#ga3922f75a3ab14f611bd610508751609f", null ]
];