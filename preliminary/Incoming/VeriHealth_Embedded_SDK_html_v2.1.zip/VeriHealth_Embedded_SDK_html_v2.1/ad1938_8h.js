var ad1938_8h =
[
    [ "AD1938_ADDR", "group___a_d1938.html#ga6c47c175da430a0af414dc73b5413a15", null ],
    [ "ad1938_device_init", "group___a_d1938.html#ga0840df00d161a0ea5d4a1664dad40bf1", null ],
    [ "ad1938_device_release", "group___a_d1938.html#ga5fc9b28d8956423cce9ae897a94added", null ]
];