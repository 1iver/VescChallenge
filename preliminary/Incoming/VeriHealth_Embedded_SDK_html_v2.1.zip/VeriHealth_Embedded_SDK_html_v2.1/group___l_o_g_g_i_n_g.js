var group___l_o_g_g_i_n_g =
[
    [ "CHECK_PARAM_FORMAT", "group___l_o_g_g_i_n_g.html#ga8481ea773cd3c992104647180b437cda", null ],
    [ "uart_debug_init", "group___l_o_g_g_i_n_g.html#ga8a5367ff24721ee112480b67cfc553dd", null ],
    [ "uart_printf", "group___l_o_g_g_i_n_g.html#gad86eee18fa2e6a743db4111396adb33b", null ],
    [ "uart_sprintf", "group___l_o_g_g_i_n_g.html#gaa73ceb0b5e36b54f4f32f5d68ae451c9", null ]
];