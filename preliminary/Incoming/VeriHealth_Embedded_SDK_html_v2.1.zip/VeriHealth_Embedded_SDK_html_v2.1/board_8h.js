var board_8h =
[
    [ "BoardDevice", "group___b_o_a_r_d.html#ga0ea66df699b2a9381e686f591cf028da", null ],
    [ "BoardOperations", "group___b_o_a_r_d.html#gabdbd851b07546735ebe150966327bf29", null ],
    [ "board_find_device_by_id", "group___b_o_a_r_d.html#gae5440b0202f28fe001798f210a4fa72b", null ],
    [ "board_get_ops", "group___b_o_a_r_d.html#ga66cc7b12ee37f4fed4072197e196e424", null ],
    [ "board_init", "group___b_o_a_r_d.html#ga52ed0dcd36a5a201ea9bca39379d9184", null ],
    [ "board_register", "group___b_o_a_r_d.html#ga66e722271be03b7832d3bcf181e8c090", null ],
    [ "get_wakeup_src", "group___b_o_a_r_d.html#gaa7d803a98004f5a8edd07cf7cfa10dae", null ]
];