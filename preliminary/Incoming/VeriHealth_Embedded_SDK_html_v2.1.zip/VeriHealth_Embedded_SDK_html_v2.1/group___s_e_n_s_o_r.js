var group___s_e_n_s_o_r =
[
    [ "_SensorReadBackData", "struct___sensor_read_back_data.html", [
      [ "raw_count", "struct___sensor_read_back_data.html#ae4f0978bd920f9503a3169078e355df6", null ],
      [ "raw_sample", "struct___sensor_read_back_data.html#a6bd5d6baa567f66c0ce2941f774a6cd0", null ],
      [ "raw_size", "struct___sensor_read_back_data.html#a91438809dc92dd983ab80560ce9d66d4", null ],
      [ "sample_status", "struct___sensor_read_back_data.html#a04b1bb117a7a180ceba7acea4d63552e", null ]
    ] ],
    [ "VpiSensorRawSta", "struct_vpi_sensor_raw_sta.html", [
      [ "len", "struct_vpi_sensor_raw_sta.html#ad752c317c2fd95a84b8bd275bc877970", null ],
      [ "mode", "struct_vpi_sensor_raw_sta.html#a42db717f0aab97af05f68d9476f6c590", null ],
      [ "raw", "struct_vpi_sensor_raw_sta.html#a0b4ea450f342d0183eb8e3a3f341b99e", null ],
      [ "ready", "struct_vpi_sensor_raw_sta.html#aecc2cc16869f7768b9164ac740c068f0", null ],
      [ "subtype", "struct_vpi_sensor_raw_sta.html#a1123bedca2fd922baf23a3d7659f95d0", null ],
      [ "time", "struct_vpi_sensor_raw_sta.html#ac77695b0f9232d52397e318e5c63ffa9", null ],
      [ "type", "struct_vpi_sensor_raw_sta.html#ab7da64178790895516e88d2ee8c056bf", null ]
    ] ],
    [ "SenRawDataBufCtrl", "struct_sen_raw_data_buf_ctrl.html", [
      [ "buf_num", "struct_sen_raw_data_buf_ctrl.html#a50f0a53c509e2fcb15cd9501e9795318", null ],
      [ "buf_sw", "struct_sen_raw_data_buf_ctrl.html#adcc8fa1ddeca2e166e30088dd020438b", null ],
      [ "buffer", "struct_sen_raw_data_buf_ctrl.html#a2d932fcfd81b9510869d5f3e1cab1faf", null ],
      [ "padding", "struct_sen_raw_data_buf_ctrl.html#a720a083cd50eac8395f24bc9acea1b14", null ],
      [ "proc_len", "struct_sen_raw_data_buf_ctrl.html#ad8bcc05ceb8b857c69e39cb7cf125a1d", null ],
      [ "rawsta", "struct_sen_raw_data_buf_ctrl.html#a8357dfcb5285d23b59a651a711a8a348", null ],
      [ "rec_idx", "struct_sen_raw_data_buf_ctrl.html#a9b5e1fa0d4e40ef7113edc64af8c2f23", null ],
      [ "rec_len", "struct_sen_raw_data_buf_ctrl.html#a17248ccc6be0da6a86acf4b23f8d1fa7", null ],
      [ "time", "struct_sen_raw_data_buf_ctrl.html#a190621539ccf6b8921a88d8d94142fda", null ]
    ] ],
    [ "SenDataProcCtrl", "struct_sen_data_proc_ctrl.html", [
      [ "buffer", "struct_sen_data_proc_ctrl.html#a859e51f4fba7b9a6279bdbf67514fea9", null ],
      [ "index", "struct_sen_data_proc_ctrl.html#ac4d61bb3e74fbf1d762205660c63c73e", null ],
      [ "samp_size", "struct_sen_data_proc_ctrl.html#a0e9f3d8d6ea5a70cd204fa85ccede519", null ]
    ] ],
    [ "SenResSetCtrlSt", "struct_sen_res_set_ctrl_st.html", [
      [ "data", "struct_sen_res_set_ctrl_st.html#a8312ecb61831f1f266716757e879af8d", null ],
      [ "grp_id", "struct_sen_res_set_ctrl_st.html#a5cebc994d2e6760e7013b7e82c5455b8", null ],
      [ "grp_mb", "struct_sen_res_set_ctrl_st.html#af2a7db2d76667a130a660f342c40a620", null ],
      [ "index", "struct_sen_res_set_ctrl_st.html#afa74b6f447b8dcc170c517ec2c819b47", null ],
      [ "len", "struct_sen_res_set_ctrl_st.html#a7b9bf4b439567d032132a95048af898c", null ]
    ] ],
    [ "SensorTransInfo", "struct_sensor_trans_info.html", [
      [ "data_type", "struct_sensor_trans_info.html#aa8f8fe68ebbb55af4cdec5e92ad6c578", null ],
      [ "packet_type", "struct_sensor_trans_info.html#afffd2c2b1eacdfa16435d81671f3aec3", null ],
      [ "trans_id", "struct_sensor_trans_info.html#a1e3d3e3f77aee2b2fc6575a52b81d2c9", null ]
    ] ],
    [ "VpiSensorCfg", "struct_vpi_sensor_cfg.html", [
      [ "channels", "struct_vpi_sensor_cfg.html#a80ec426c130b8ef9fa577ca9990a32ac", null ],
      [ "data_fmt", "struct_vpi_sensor_cfg.html#a9bec2dfeb5c6547e6b8429c02e44d721", null ],
      [ "mode", "struct_vpi_sensor_cfg.html#a480ff74439566360928e79da6002301d", null ],
      [ "sample_rate", "struct_vpi_sensor_cfg.html#ab7e0a612fee709e1673645cc90c0b66f", null ]
    ] ],
    [ "VpiSenRawProp", "struct_vpi_sen_raw_prop.html", [
      [ "compress", "struct_vpi_sen_raw_prop.html#a21d0e41423302a95cfc67cdd38f169ec", null ],
      [ "encrypt", "struct_vpi_sen_raw_prop.html#a264262f748828865ee81159bb854eed8", null ],
      [ "end", "struct_vpi_sen_raw_prop.html#a7cea70cfca48a1c1d8ed99cf3b5d9f18", null ],
      [ "in_raw", "struct_vpi_sen_raw_prop.html#a89d6561d305fb3fec3d05b912ef08369", null ],
      [ "in_raw_size", "struct_vpi_sen_raw_prop.html#a423abd1eb0aed623271a3c29057e997d", null ],
      [ "msb", "struct_vpi_sen_raw_prop.html#a1b40bf82d5466de4c00067424d827dc6", null ],
      [ "out_buf", "struct_vpi_sen_raw_prop.html#ae6335fdcfdb204e8e28db214c5b2355a", null ],
      [ "out_size", "struct_vpi_sen_raw_prop.html#a30696dffbf661e824603f239cc441c79", null ],
      [ "start", "struct_vpi_sen_raw_prop.html#a51e362aa7789317c77bcb30f593289f7", null ],
      [ "timestamp", "struct_vpi_sen_raw_prop.html#a111c2ee80721fa4a88f334be1870a036", null ],
      [ "type", "struct_vpi_sen_raw_prop.html#a2666718a35dc74a16e3ec2a731cd3f07", null ]
    ] ],
    [ "VpiSenResultProp", "struct_vpi_sen_result_prop.html", [
      [ "duration", "struct_vpi_sen_result_prop.html#a0933d888e56eeb3d387e02e4dfc28dac", null ],
      [ "encrypt", "struct_vpi_sen_result_prop.html#a9f6c80d3612f23bf99736d92d48bea05", null ],
      [ "end", "struct_vpi_sen_result_prop.html#a9db09b478bcd45c99c9a561b2afcea53", null ],
      [ "start", "struct_vpi_sen_result_prop.html#a7fe0aadb632bed69883c057fd9f0f0c4", null ],
      [ "timestamp", "struct_vpi_sen_result_prop.html#a273775fac637d098a82ae995be123821", null ]
    ] ],
    [ "SenResInfo", "struct_sen_res_info.html", [
      [ "abnormal", "struct_sen_res_info.html#aeb67217c8210b1978c5f79e9fda5090d", null ],
      [ "category_id", "struct_sen_res_info.html#ae76d4422b35bfab570ab70aad1e6153c", null ],
      [ "reserved", "struct_sen_res_info.html#a2094021c312ca7673a8a52d90b796fbb", null ],
      [ "value", "struct_sen_res_info.html#a748d40ba908d82a3f7ac8aaf06aad476", null ]
    ] ],
    [ "MAX_RES_GRP_MEMBER_NUM", "group___s_e_n_s_o_r.html#ga67d9b1a5df9f53028d42ef5403cce694", null ],
    [ "MAX_RES_GRP_NUM", "group___s_e_n_s_o_r.html#ga1b0cd96e34ed2f94802b4bb0415489af", null ],
    [ "RAW_DATA_HEADER_SIZE", "group___s_e_n_s_o_r.html#ga8d9f0eec98ec6dee04c6281eff6e7d79", null ],
    [ "RESULT_DATA_HEADER_SIZE", "group___s_e_n_s_o_r.html#gae9e88103a8afba51f191f1cd000c79ca", null ],
    [ "SENSOR_NAME_SIZE", "group___s_e_n_s_o_r.html#gabc0f5aad9466c1bcd36dcc95b367d1e8", null ],
    [ "DataCompressHandler", "group___s_e_n_s_o_r.html#ga8c9b3e5893a8e8b4e6f8d1eb8ef97772", null ],
    [ "DataEncryptHandler", "group___s_e_n_s_o_r.html#gac3571ff06cacdf706003410649e1047a", null ],
    [ "EcgDataType", "group___s_e_n_s_o_r.html#gaf477bee497e1b7aa01ceb03b456be58e", null ],
    [ "ImuDataType", "group___s_e_n_s_o_r.html#ga66f425df5a972aa811be96d6fb38bab6", null ],
    [ "PpgDataType", "group___s_e_n_s_o_r.html#ga6c5c565adb31263db945c355ee02e1d6", null ],
    [ "SenDataHandler", "group___s_e_n_s_o_r.html#ga4617ad69e63ee8a587294cb3350c3e22", null ],
    [ "SenDataProcCtrl", "group___s_e_n_s_o_r.html#ga86ba7d79282bfb9331c37a4262a39de7", null ],
    [ "SenDataProcHandler", "group___s_e_n_s_o_r.html#gae49ef67c5aa932f20a56b505a36accd9", null ],
    [ "SenPacketType", "group___s_e_n_s_o_r.html#ga71b641f7a326060092c2102c4bcb20f9", null ],
    [ "SenRawDataBufCtrl", "group___s_e_n_s_o_r.html#ga62df146fed5e6aeb65ea1e1e3b5a2eca", null ],
    [ "SenRawDataFormat", "group___s_e_n_s_o_r.html#ga9fff712c3f22da23ea4011a831a7abe1", null ],
    [ "SenResInfoType", "group___s_e_n_s_o_r.html#gaf2d56481b6afa0ba1a4bbdb6e0f0bf4a", null ],
    [ "SenResSetCtrl", "group___s_e_n_s_o_r.html#ga6b963fb57d3a93772c322cf6992fc007", null ],
    [ "SenResultDataType", "group___s_e_n_s_o_r.html#ga5eb85d710854493b0c9ac4a8f34050dc", null ],
    [ "SensorDataPacket", "group___s_e_n_s_o_r.html#ga628a2a8e81240a91042cbb958c6df569", null ],
    [ "SensorDataReadyHandler", "group___s_e_n_s_o_r.html#ga53671bb10cd40478d0fef6799446925e", null ],
    [ "SensorReadBackData", "group___s_e_n_s_o_r.html#ga19d6f4faa3e4448ec2e15e2cbb774ae4", null ],
    [ "SensorReadBackHandler", "group___s_e_n_s_o_r.html#gada9b9efb7f388d16c7a951d32a9c488a", null ],
    [ "SensorType", "group___s_e_n_s_o_r.html#gaea29b4a104f6d2371d61346653fa40db", null ],
    [ "SportType", "group___s_e_n_s_o_r.html#ga7b6a77db8ef0a1684570796f4ff52273", null ],
    [ "TmpDataType", "group___s_e_n_s_o_r.html#gad590ac2e0bb9fa19312f5c355fb721a4", null ],
    [ "UserPhyStatus", "group___s_e_n_s_o_r.html#ga9f0a1eb3db144328251509c113f63865", null ],
    [ "VpiSensorRawSta", "group___s_e_n_s_o_r.html#ga33a17147c532a45b22c6b2df0cb4bd29", null ],
    [ "VpiSensorRawStaPointArr", "group___s_e_n_s_o_r.html#ga8a0341da41876b5900f64edb98131fd6", null ],
    [ "VpiSensorRawStaPointArrHandle", "group___s_e_n_s_o_r.html#gabe7bf8cd782119edc6f621b5f4ef2001", null ],
    [ "e_ppg_sample_format", "group___s_e_n_s_o_r.html#gac9348c37450ca2d80a465d2841863310", [
      [ "SENSOR_SAMPLE_2_BYTE_LITTLEENDIAN", "group___s_e_n_s_o_r.html#ggac9348c37450ca2d80a465d2841863310acf5d8bfa5d620ab3ef4f71277d2a94fc", null ],
      [ "SENSOR_SAMPLE_4_BYTE_LITTLEENDIAN", "group___s_e_n_s_o_r.html#ggac9348c37450ca2d80a465d2841863310a1f587db409077dd159320960464a0fca", null ],
      [ "SENSOR_SAMPLE_3_BYTE_LITTLEENDIAN", "group___s_e_n_s_o_r.html#ggac9348c37450ca2d80a465d2841863310a442b957827afe16f51e35ffb167a1991", null ],
      [ "SENSOR_SAMPLE_2_BYTE_BIGENDIAN", "group___s_e_n_s_o_r.html#ggac9348c37450ca2d80a465d2841863310adcba6c918c95ad8ece2613eef0dd6703", null ],
      [ "SENSOR_SAMPLE_4_BYTE_BIGENDIAN", "group___s_e_n_s_o_r.html#ggac9348c37450ca2d80a465d2841863310a46aa50d5c150e58eaf388dd178fdbe69", null ],
      [ "SENSOR_SAMPLE_3_BYTE_BIGENDIAN", "group___s_e_n_s_o_r.html#ggac9348c37450ca2d80a465d2841863310aa5af31f22c3b013b0f509bc40b5c7081", null ]
    ] ],
    [ "e_sensor_type", "group___s_e_n_s_o_r.html#ga2d6aca7c4d43ae9f48051f3d09218520", [
      [ "SENSOR_TYPE_NONE", "group___s_e_n_s_o_r.html#gga2d6aca7c4d43ae9f48051f3d09218520a3f8e3e31e6a356192f150019309925ee", null ],
      [ "SENSOR_TYPE_PPG", "group___s_e_n_s_o_r.html#gga2d6aca7c4d43ae9f48051f3d09218520a9482daa05a9f417e468c8de6aa2ba5c1", null ],
      [ "SENSOR_TYPE_ECG", "group___s_e_n_s_o_r.html#gga2d6aca7c4d43ae9f48051f3d09218520ac4ae15358bd021519e3b295e27c060e1", null ],
      [ "SENSOR_TYPE_TMP", "group___s_e_n_s_o_r.html#gga2d6aca7c4d43ae9f48051f3d09218520a43fd11152d6575e7c01e33f3dfc2d9cb", null ],
      [ "SENSOR_TYPE_IMU", "group___s_e_n_s_o_r.html#gga2d6aca7c4d43ae9f48051f3d09218520ae760cee775c0fb234687d279db3ff1d9", null ]
    ] ],
    [ "EcgDataType", "group___s_e_n_s_o_r.html#gae8f878804e79d895e7c3094f14db6383", [
      [ "ECG_DATA_NONE", "group___s_e_n_s_o_r.html#ggae8f878804e79d895e7c3094f14db6383aafd8beb1a21174374b1551b71c2ba6d3", null ],
      [ "ECG_DATA_RAW", "group___s_e_n_s_o_r.html#ggae8f878804e79d895e7c3094f14db6383ae7d6212dc7f2ac3b92045f760edb50fb", null ],
      [ "ECG_DATA_RR", "group___s_e_n_s_o_r.html#ggae8f878804e79d895e7c3094f14db6383adb35610acd2ae79b1eedb9f43f89477e", null ],
      [ "EEG_DATA_PREPROC", "group___s_e_n_s_o_r.html#ggae8f878804e79d895e7c3094f14db6383acfcdbac076f7e8b884c4a15ac79183ff", null ],
      [ "EEG_DATA_FREQ_SPEC", "group___s_e_n_s_o_r.html#ggae8f878804e79d895e7c3094f14db6383a38278b80a1fec24514909bc140b7381f", null ],
      [ "ECG_DATA_MAX", "group___s_e_n_s_o_r.html#ggae8f878804e79d895e7c3094f14db6383a99935ea330d94aeb6b231d4a867fe6ab", null ]
    ] ],
    [ "ImuDataType", "group___s_e_n_s_o_r.html#ga9793c67ce447703b86bb4ec5fccb8486", [
      [ "IMU_DATA_NONE", "group___s_e_n_s_o_r.html#gga9793c67ce447703b86bb4ec5fccb8486a11d28b9f6633c4d992274aa878a0c055", null ],
      [ "IMU_DATA_ACCL_RAW", "group___s_e_n_s_o_r.html#gga9793c67ce447703b86bb4ec5fccb8486a103e8478cf120faf394d31f274038d59", null ],
      [ "IMU_DATA_GYRO_RAW", "group___s_e_n_s_o_r.html#gga9793c67ce447703b86bb4ec5fccb8486ac944432aa02df140f270ad01bc415e8d", null ],
      [ "IMU_DATA_GYRO_ACCL_RAW", "group___s_e_n_s_o_r.html#gga9793c67ce447703b86bb4ec5fccb8486a22c74d83ff8009e54707db5b07824c12", null ],
      [ "IMU_DATA_MAG_RAW", "group___s_e_n_s_o_r.html#gga9793c67ce447703b86bb4ec5fccb8486ad5286ca66b4379935dcd2a09fe7dada2", null ],
      [ "IMU_DATA_SF", "group___s_e_n_s_o_r.html#gga9793c67ce447703b86bb4ec5fccb8486addd2913240646fc984c1276564c3b3e2", null ],
      [ "IMU_DATA_MAX", "group___s_e_n_s_o_r.html#gga9793c67ce447703b86bb4ec5fccb8486a5b29b7111e9c76a7977aa60a2ccb5886", null ]
    ] ],
    [ "PpgDataType", "group___s_e_n_s_o_r.html#gab417f38767727ecc0cfc2ea195d9ffaf", [
      [ "PPG_DATA_NONE", "group___s_e_n_s_o_r.html#ggab417f38767727ecc0cfc2ea195d9ffafadc672940146aa8a4a963226054a3170b", null ],
      [ "PPG_DATA_GREEN_RAW", "group___s_e_n_s_o_r.html#ggab417f38767727ecc0cfc2ea195d9ffafa66e5c5a33c6ba0e404f94e9b22d7cb81", null ],
      [ "PPG_DATA_REDIR_RAW", "group___s_e_n_s_o_r.html#ggab417f38767727ecc0cfc2ea195d9ffafadd424fee905dd2192ce9fc549996bd8e", null ],
      [ "PPG_DATA_REDIRGREEN_RAW", "group___s_e_n_s_o_r.html#ggab417f38767727ecc0cfc2ea195d9ffafaabbc37cf03b99439ffe7411e8b2a9e51", null ],
      [ "PPG_DATA_GREEN_RB", "group___s_e_n_s_o_r.html#ggab417f38767727ecc0cfc2ea195d9ffafa87caa9db4e708eed758267cc9ef73a39", null ],
      [ "PPG_DATA_IR_RB", "group___s_e_n_s_o_r.html#ggab417f38767727ecc0cfc2ea195d9ffafaff125401ad8904c8c44ff35cc3bec8c3", null ],
      [ "PPG_DATA_MAX", "group___s_e_n_s_o_r.html#ggab417f38767727ecc0cfc2ea195d9ffafa914b23cb56eac6d3fcfd7e1baba3b956", null ]
    ] ],
    [ "SenDataCompProp", "group___s_e_n_s_o_r.html#ga3c2cf20e8c35fe0416f034e5d26917e5", [
      [ "COMPRESS_DATA", "group___s_e_n_s_o_r.html#gga3c2cf20e8c35fe0416f034e5d26917e5a32ec289d80739f1d34894c01c5ca5150", null ],
      [ "RAW_DATA", "group___s_e_n_s_o_r.html#gga3c2cf20e8c35fe0416f034e5d26917e5aa95b1e6d1fcdbcc145322e678f06f8dd", null ]
    ] ],
    [ "SenDataEncProp", "group___s_e_n_s_o_r.html#ga69110351ad537dea0d3470838fd96211", [
      [ "UNENCRYPTED", "group___s_e_n_s_o_r.html#gga69110351ad537dea0d3470838fd96211abcb681c9d6a881c58a7060f6730bbd94", null ],
      [ "ENCRYPTED", "group___s_e_n_s_o_r.html#gga69110351ad537dea0d3470838fd96211aaac875c4dc08055725dd966fd44e0839", null ]
    ] ],
    [ "SenDataEndProp", "group___s_e_n_s_o_r.html#ga4a3c2743a80bd5febe50599325187d95", [
      [ "LSB_FIRST", "group___s_e_n_s_o_r.html#gga4a3c2743a80bd5febe50599325187d95aa7a58f44a10c5b3ff637d315043f1767", null ],
      [ "MSB_FIRST", "group___s_e_n_s_o_r.html#gga4a3c2743a80bd5febe50599325187d95a89da3ebae748913c4ea84ed340c20aec", null ]
    ] ],
    [ "SenDataType", "group___s_e_n_s_o_r.html#ga02dc5a38dd980f8498ee5ce2c20e1add", [
      [ "SEN_DATA_TYPE_RAW", "group___s_e_n_s_o_r.html#gga02dc5a38dd980f8498ee5ce2c20e1adda4da00c1e99ddc475d7f541af892be628", null ],
      [ "SEN_DATA_TYPE_RESULT", "group___s_e_n_s_o_r.html#gga02dc5a38dd980f8498ee5ce2c20e1adda83aa07397f27e91b3d7dbfd7301cf961", null ],
      [ "SEN_DATA_TYPE_MAX", "group___s_e_n_s_o_r.html#gga02dc5a38dd980f8498ee5ce2c20e1adda19ff6f957eaec40e444b36e02cd4c9be", null ]
    ] ],
    [ "SenPacketType", "group___s_e_n_s_o_r.html#ga06fdec755a46d7c839026032b68788ff", [
      [ "SEN_PACKET_EMPTY", "group___s_e_n_s_o_r.html#gga06fdec755a46d7c839026032b68788ffaf545a9d11a3f7157d52b84120a9b93b7", null ],
      [ "SEN_PACKET_RT_RAW", "group___s_e_n_s_o_r.html#gga06fdec755a46d7c839026032b68788ffa22ea05178030899bc8dc8790cb0c31e1", null ],
      [ "SEN_PACKET_RT_RESULT", "group___s_e_n_s_o_r.html#gga06fdec755a46d7c839026032b68788ffaf8ffd29cb13cc180db2b3ce583616e63", null ],
      [ "SEN_PACKET_CACHED", "group___s_e_n_s_o_r.html#gga06fdec755a46d7c839026032b68788ffa4c7bf3700ae4284d2c4c6e24a5a27293", null ],
      [ "SEN_PACKET_MAX", "group___s_e_n_s_o_r.html#gga06fdec755a46d7c839026032b68788ffa100b7feb40a0d4109e62aff6ec0220d0", null ]
    ] ],
    [ "SenRawDataFormat", "group___s_e_n_s_o_r.html#gae6e34e0467d9556b4cf7027e22c400f7", [
      [ "DATA_FORMAT_U32_RAW", "group___s_e_n_s_o_r.html#ggae6e34e0467d9556b4cf7027e22c400f7ae7e5e0cf70e56a49105ebab705ff0ac9", null ],
      [ "DATA_FORMAT_S32_RAW", "group___s_e_n_s_o_r.html#ggae6e34e0467d9556b4cf7027e22c400f7a0d6a6a3daf10de5175f420f6f2b3dbe0", null ],
      [ "DATA_FORMAT_U16_RAW", "group___s_e_n_s_o_r.html#ggae6e34e0467d9556b4cf7027e22c400f7a5c772619823fd82d34e79fae643acf45", null ],
      [ "DATA_FORMAT_S16_RAW", "group___s_e_n_s_o_r.html#ggae6e34e0467d9556b4cf7027e22c400f7afed30e0d0350f061a6b47a8d212309db", null ],
      [ "DATA_FORMAT_U24_RAW", "group___s_e_n_s_o_r.html#ggae6e34e0467d9556b4cf7027e22c400f7ad5cc9db933abda138240c04415b7f0e3", null ],
      [ "DATA_FORMAT_S24_RAW", "group___s_e_n_s_o_r.html#ggae6e34e0467d9556b4cf7027e22c400f7afdd8efd209f84a82acb4069dc58af16e", null ]
    ] ],
    [ "SenResInfoType", "group___s_e_n_s_o_r.html#ga81476c2cb0eb5beeb6e4f0c23989c40e", [
      [ "RES_INFO_TYPE_USER_STA", "group___s_e_n_s_o_r.html#gga81476c2cb0eb5beeb6e4f0c23989c40ea594d846a67ccf990ab5aadb272a2aa5d", null ],
      [ "RES_INFO_TYPE_SPORT", "group___s_e_n_s_o_r.html#gga81476c2cb0eb5beeb6e4f0c23989c40eaf641712a235b792bdcb2adc402c95bb7", null ]
    ] ],
    [ "SenResultDataType", "group___s_e_n_s_o_r.html#ga55fdd4597eae9a9b3b8c1b0a87f36e7f", [
      [ "RES_TYPE_INFO", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa8b8629b07c7215496a5d3bd1c5407216", null ],
      [ "RES_TYPE_HR", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fabb223eb9285bb9d878a5827ca157e7da", null ],
      [ "RES_TYPE_RR", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fab69a8ec0680a70bf4d91c5cd223cf0b2", null ],
      [ "RES_TYPE_SPO2", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7faec741b3bdfac5d49a72dbb9169bc6ffd", null ],
      [ "RES_TYPE_TMP", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7faaf6b1658d50f461fc1795f57db5fcd39", null ],
      [ "RES_TYPE_STEP", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fac8bd05bd52a1d5d18aff8ef38673fa28", null ],
      [ "RES_TYPE_BP", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa0fd634430066c5439055984d6b3b02e1", null ],
      [ "RES_TYPE_GLUCOSE", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fafc835e79e3c15f79523f017ffe7fd161", null ],
      [ "RES_TYPE_SQ", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fad03a77d67d6e497e682fac7c28ee408f", null ],
      [ "RES_TYPE_PAI", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa6fee07e182f78b2c47f9e3595dc71dd3", null ],
      [ "RES_TYPE_HRMAX", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa1b8bb75deb92efdc88c023364cf1ddfd", null ],
      [ "RES_TYPE_HRREST", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa5e3c029ef9b30f8eb3de39232ec865f7", null ],
      [ "RES_TYPE_CC", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa3e6d4049996e52a431fc6077f9c9eb78", null ],
      [ "RES_TYPE_BMR", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fafc6b2adf77311a6a4a163eff2b1f6a14", null ],
      [ "RES_TYPE_SED", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fac8da30e50dc96d2c3747431f55b22c74", null ],
      [ "RES_TYPE_HRV", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa8cd2f2d81b238ac4b30203dfdfb94ed4", null ],
      [ "RES_TYPE_AFIB", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa2d10eb8258763fef16e49228e854d3f6", null ],
      [ "RES_TYPE_PPG_SQI", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa9bc0ea8f9969e2feb849c1dbf95c990c", null ],
      [ "RES_TYPE_ATTENTION", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa6359a7fd4faeaf51be38080f5a75e373", null ],
      [ "RES_TYPE_MAX", "group___s_e_n_s_o_r.html#gga55fdd4597eae9a9b3b8c1b0a87f36e7fa1071b795fa0a361f9ff26e8eb222a3aa", null ]
    ] ],
    [ "SensorType", "group___s_e_n_s_o_r.html#ga213c434cb928c4ca22513e2302632435", [
      [ "SEN_TYPE_NONE", "group___s_e_n_s_o_r.html#gga213c434cb928c4ca22513e2302632435a2afad63b6a46ed1d4f0354eb7ddd137d", null ],
      [ "SEN_TYPE_PPG", "group___s_e_n_s_o_r.html#gga213c434cb928c4ca22513e2302632435a6aaad7964062cc18cb7bf2693a67731d", null ],
      [ "SEN_TYPE_ECG", "group___s_e_n_s_o_r.html#gga213c434cb928c4ca22513e2302632435a5d87bd6352e76b9fece4dc0bd8984965", null ],
      [ "SEN_TYPE_IMU", "group___s_e_n_s_o_r.html#gga213c434cb928c4ca22513e2302632435a8dd13d99ba252409f3cb706a3eb50e6a", null ],
      [ "SEN_TYPE_TMP", "group___s_e_n_s_o_r.html#gga213c434cb928c4ca22513e2302632435aca92d2a2d4e57a52242a4d8d321acaca", null ],
      [ "SEN_TYPE_MAX", "group___s_e_n_s_o_r.html#gga213c434cb928c4ca22513e2302632435ad6985773c786d45bd24f4659d691838f", null ]
    ] ],
    [ "SportType", "group___s_e_n_s_o_r.html#ga862f2645d4203f62929203bf30205db1", [
      [ "SPORT_TYPE_WALK", "group___s_e_n_s_o_r.html#gga862f2645d4203f62929203bf30205db1a770e2a47b096677306ccca51fd05112e", null ],
      [ "SPORT_TYPE_RUN", "group___s_e_n_s_o_r.html#gga862f2645d4203f62929203bf30205db1a7ab1a44d7f3eb7138dd1b5012a6cd8da", null ],
      [ "SPORT_TYPE_SWIM", "group___s_e_n_s_o_r.html#gga862f2645d4203f62929203bf30205db1a7304629f048d4110d24994932d4cd7aa", null ]
    ] ],
    [ "TmpDataType", "group___s_e_n_s_o_r.html#ga61dc37ba4288b6d0094bf7d931a1e936", [
      [ "TMP_DATA_NONE", "group___s_e_n_s_o_r.html#gga61dc37ba4288b6d0094bf7d931a1e936a5f487486ae0c2593365cc9535a24753d", null ],
      [ "TMP_DATA_RAW", "group___s_e_n_s_o_r.html#gga61dc37ba4288b6d0094bf7d931a1e936ae83979b521c79e9e42f561837978db33", null ],
      [ "TMP_DATA_MAX", "group___s_e_n_s_o_r.html#gga61dc37ba4288b6d0094bf7d931a1e936ab42fadc123fdd70b0db0b8d68364537e", null ]
    ] ],
    [ "UserPhyStatus", "group___s_e_n_s_o_r.html#ga2d1bf067d006214769161d5e8eb04830", [
      [ "USER_PHY_STA_STILL", "group___s_e_n_s_o_r.html#gga2d1bf067d006214769161d5e8eb04830a91931ef360b3d16bc1dbab4252d78339", null ],
      [ "USER_PHY_STA_WALK", "group___s_e_n_s_o_r.html#gga2d1bf067d006214769161d5e8eb04830aa347d0f7646551056d239e38a4c9fd61", null ],
      [ "USER_PHY_STA_SLEEP", "group___s_e_n_s_o_r.html#gga2d1bf067d006214769161d5e8eb04830aa0b7650635167fabb9bc3bca23fde7a5", null ],
      [ "USER_PHY_STA_SPORT", "group___s_e_n_s_o_r.html#gga2d1bf067d006214769161d5e8eb04830adfc287101ce8f751f6f506910e8533c9", null ],
      [ "USER_PHY_STA_NAP", "group___s_e_n_s_o_r.html#gga2d1bf067d006214769161d5e8eb04830ad093ba845bf4be773dfd57d288c2c0d2", null ]
    ] ],
    [ "__attribute", "group___s_e_n_s_o_r.html#gac9916fd7fc98b5752ee0d65b6524230f", null ],
    [ "vpi_sensor_ack_stg_pack", "group___s_e_n_s_o_r.html#ga54e0fb95c4b8411ebdd92b9bfa643ed0", null ],
    [ "vpi_sensor_data_process", "group___s_e_n_s_o_r.html#gac70440c2fbc382d809755ffb5aeab784", null ],
    [ "vpi_sensor_data_process_destroy", "group___s_e_n_s_o_r.html#gab13abb8007b77484790449e99a4b0756", null ],
    [ "vpi_sensor_data_process_flush", "group___s_e_n_s_o_r.html#ga9a43fafd00d4fd2a5f4cb126aa653634", null ],
    [ "vpi_sensor_data_process_init", "group___s_e_n_s_o_r.html#gac2c25d56b73d5f31c2bbb4d732b0b4b0", null ],
    [ "vpi_sensor_flush_raw_pack", "group___s_e_n_s_o_r.html#ga27445f221b9eb930967ae7f77569ae11", null ],
    [ "vpi_sensor_gen_result_packet", "group___s_e_n_s_o_r.html#ga4acc6f35f574d1d100707372589b44ba", null ],
    [ "vpi_sensor_get_core_temperature", "group___s_e_n_s_o_r.html#gad91d983db2f8aa0c2c81c80ae3ec3ec6", null ],
    [ "vpi_sensor_get_res_rt_slices", "group___s_e_n_s_o_r.html#ga0ce3f6a1c1ccc6ef4ed9f458a993ddfb", null ],
    [ "vpi_sensor_get_res_stg_slices", "group___s_e_n_s_o_r.html#gae66f54f1b1871d0f3e66fe770c11d9c7", null ],
    [ "vpi_sensor_init_stg_pack_ctrl", "group___s_e_n_s_o_r.html#gadd310caae83f18561fd7debe16963f82", null ],
    [ "vpi_sensor_is_stg_pack_empty", "group___s_e_n_s_o_r.html#gae1d3f7d1c45ac8baf583499df811a72e", null ],
    [ "vpi_sensor_make_raw_pack", "group___s_e_n_s_o_r.html#gab158f35d1958b102635742cab825b560", null ],
    [ "vpi_sensor_packet_init", "group___s_e_n_s_o_r.html#ga7ace40391c3b2279ed6a05446606a1dd", null ],
    [ "vpi_sensor_packet_is_empty", "group___s_e_n_s_o_r.html#gae8faadc5500bcf28a5b143a50445dc5b", null ],
    [ "vpi_sensor_packet_is_full", "group___s_e_n_s_o_r.html#ga64ecf75acfda5b2c96d5ac1033886558", null ],
    [ "vpi_sensor_packet_peek", "group___s_e_n_s_o_r.html#ga8cbd4c6c350237328c5780d632e1ce9f", null ],
    [ "vpi_sensor_parse_trans_info", "group___s_e_n_s_o_r.html#gaae88016b0499f2b12b0a9a65ac427ec0", null ],
    [ "vpi_sensor_print_stg_pack_ctrl_msg", "group___s_e_n_s_o_r.html#gac0f2121ed1c27116dc7d1179f9af93fe", null ],
    [ "vpi_sensor_rawdata_destroy", "group___s_e_n_s_o_r.html#ga9ac7816619e2ee0fc6d439171794e1c0", null ],
    [ "vpi_sensor_rawdata_get_write_addr", "group___s_e_n_s_o_r.html#gaed682140f1c66009c712373cca69c672", null ],
    [ "vpi_sensor_rawdata_init", "group___s_e_n_s_o_r.html#ga878c2ad8a22ceaf509365309d5b40762", null ],
    [ "vpi_sensor_rawdata_push", "group___s_e_n_s_o_r.html#ga6ca63d30e80aaa62c103d871980f3597", null ],
    [ "vpi_sensor_rawdata_reset", "group___s_e_n_s_o_r.html#ga34ccf22f714ad3947caef711d67c9ce2", null ],
    [ "vpi_sensor_rel_raw_pack", "group___s_e_n_s_o_r.html#gaaad9a7e94c5e8d44af07d81476a59e00", null ],
    [ "vpi_sensor_rel_result_packet", "group___s_e_n_s_o_r.html#ga267177555e5b14775012afc7718534b8", null ],
    [ "vpi_sensor_reset_stg_pack_ctrl", "group___s_e_n_s_o_r.html#ga979520e90a38632241e0c98b613bde30", null ],
    [ "vpi_sensor_result_add_data", "group___s_e_n_s_o_r.html#ga8ddbe45feb6baa27a55c788c7205431b", null ],
    [ "vpi_sensor_result_set_init", "group___s_e_n_s_o_r.html#gaf23ce72942fa3542a02f0fe1c9dc5fdc", null ],
    [ "vpi_sensor_ringbuf_init", "group___s_e_n_s_o_r.html#gabef1535fbd92ac270b6128fa25addcf8", null ],
    [ "vpi_sensor_send_empty_raw_pack", "group___s_e_n_s_o_r.html#ga1cb9be07cd5ac94e7159fea40c628398", null ],
    [ "vpi_sensor_send_pack_in_stg", "group___s_e_n_s_o_r.html#ga7e93a96291c40f2ec72eaae94f5acd48", null ],
    [ "vpi_sensor_set_compress_fun", "group___s_e_n_s_o_r.html#ga97921e192f0306ff9d0b2049693da7b4", null ],
    [ "vpi_sensor_set_encrypt_fun", "group___s_e_n_s_o_r.html#gaff725f9e2a20803fef1c5121c7e8bbee", null ],
    [ "vpi_sensor_set_raw_test_flag", "group___s_e_n_s_o_r.html#ga8032c69eed1d5b9d6629729b7a1c122c", null ],
    [ "vpi_sensor_set_res_test_flag", "group___s_e_n_s_o_r.html#ga3a7f744a7437c9a20cfd190daf6876fb", null ],
    [ "vpi_sensor_stg_all_res_pack", "group___s_e_n_s_o_r.html#ga74254a00819ed4a78718cfdb7bacd26c", null ],
    [ "vpi_sensor_stg_raw_pack", "group___s_e_n_s_o_r.html#gae5f8cb1d152f93c7c7f35f75fda2996e", null ],
    [ "vpi_sensor_stg_res_pack", "group___s_e_n_s_o_r.html#ga03f23e7b65af002606d36aa42c1ed282", null ],
    [ "vpi_sensor_storage_init", "group___s_e_n_s_o_r.html#ga346d7d0dce0909457d18debc7cad3e02", null ],
    [ "__attribute", "group___s_e_n_s_o_r.html#ga23801af17291fc3811ccae829ae926c8", null ]
];