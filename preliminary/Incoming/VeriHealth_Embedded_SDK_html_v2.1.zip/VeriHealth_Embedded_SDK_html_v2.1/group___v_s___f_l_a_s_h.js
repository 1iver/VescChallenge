var group___v_s___f_l_a_s_h =
[
    [ "vs_spiflash_device_deinit", "group___v_s___f_l_a_s_h.html#ga718ec7af591e84b5a856910ae5e56907", null ],
    [ "vs_spiflash_device_init", "group___v_s___f_l_a_s_h.html#ga3ae3f3466158f5d119e68909c18f8c93", null ]
];