var group___s_o_c =
[
    [ "PEGASUS", "group___p_e_g_a_s_u_s.html", "group___p_e_g_a_s_u_s" ],
    [ "SocIfInfo", "union_soc_if_info.html", [
      [ "channel", "union_soc_if_info.html#ac1d3a80d59cd3ff8cf39c99decd8210b", null ],
      [ "device_id", "union_soc_if_info.html#ac4d41ffe7383ca2508ee9344e683b71c", null ],
      [ "port", "union_soc_if_info.html#a0ac7f4d57bb4fb4ce3917f7433dcf0d1", null ],
      [ "pwm", "union_soc_if_info.html#a4f72862921a9f35e0ccf59308697b8c6", null ]
    ] ],
    [ "GpioMuxCfg", "struct_gpio_mux_cfg.html", [
      [ "info", "struct_gpio_mux_cfg.html#a412053864cdfe51e2a0475f1fe97e773", null ],
      [ "value", "struct_gpio_mux_cfg.html#a25f7ecd5c72660af275b49852d95b570", null ]
    ] ],
    [ "SocPinCtl", "struct_soc_pin_ctl.html", [
      [ "cfg", "struct_soc_pin_ctl.html#a544e5a9e636eaebd1b50748afc81df15", null ],
      [ "idx", "struct_soc_pin_ctl.html#aa18972e2c9fc0788f2b8c378828ebbdf", null ]
    ] ],
    [ "SOC_PAD", "group___s_o_c.html#ga13892931e6e9ec68e65aca315543be98", null ],
    [ "SW_DS", "group___s_o_c.html#ga89799af642b307c005340dac5302ad37", null ],
    [ "SW_IN", "group___s_o_c.html#gabbd8d55fe0b2029194790ea88973e6bc", null ],
    [ "SW_IOKEEP", "group___s_o_c.html#gaf923cdaa15d0198ff173385c18c62a4c", null ],
    [ "SW_MUX", "group___s_o_c.html#gabfbb1bfabec98c6ea397b06beb28fae2", null ],
    [ "SW_OD", "group___s_o_c.html#gac969f1a230ab2f453a3529dbf3150678", null ],
    [ "SW_PD", "group___s_o_c.html#gafbdd6f15d5abc798ec85ee14fa97aa66", null ],
    [ "SW_PU", "group___s_o_c.html#ga99e3510abf0db56342a62295da0e43a0", null ],
    [ "SW_ST", "group___s_o_c.html#ga51d0136ff5b937e21e1ae4b3dad5459a", null ],
    [ "GpioMuxCfg", "group___s_o_c.html#ga5ff129f00380eebc6aebbd453eae05cc", null ],
    [ "SocIfInfo", "group___s_o_c.html#gafd60d0a2effe4fa4f4d48292d59bca4b", null ],
    [ "SocInterfaceDef", "group___s_o_c.html#gac34c18740a9367aa9095128387037567", null ],
    [ "SocPinCtl", "group___s_o_c.html#gab4fe3c496c85906b2125981e6bda0978", null ],
    [ "SocInterfaceDef", "group___s_o_c.html#ga89be7a04490201d5126d56e0abee654c", [
      [ "SOC_IF_GPIO", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654cadd0b2356fd5b4aefde9fd0edfeb8f1c0", null ],
      [ "SOC_IF_HOST_JTAG", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca72345ea3fe2a7fd3c582c2ebfd73bc02", null ],
      [ "SOC_IF_BLE_JTAG", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654caff61d3ed2408d621217c2db50e0489e4", null ],
      [ "SOC_IF_AUDIO_JTAG", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654cac41ec602b547652af8b7ec2176e2bcd2", null ],
      [ "SOC_IF_UART", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654cab588ca890ee67d3ad132412372367ede", null ],
      [ "SOC_IF_QSPI", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca955458d9ce7c26cd0046f6cfa0911719", null ],
      [ "SOC_IF_SPI", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654caafa97d61d275153766cb21e6d5ca6e6f", null ],
      [ "SOC_IF_I2C", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca34b018f612513db7f8da98c937aa0c57", null ],
      [ "SOC_IF_I3C", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca0dd55638348dd1e9bf3975a9cd00ef1a", null ],
      [ "SOC_IF_PWM", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca3b2fb1abca75f19dbff399966cb73333", null ],
      [ "SOC_IF_USB", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654cafa302590f7a527ba3d3f9c05fc17a78b", null ],
      [ "SOC_IF_I2S", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca2fa307bef2bbfaf24abbc9361f662c65", null ],
      [ "SOC_IF_PDM", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca4191e9a67e1e4d8e2a52ecee80efb823", null ],
      [ "SOC_IF_DAC_OUT", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654cac379a4f2a59e3f3c439faddcfce1c656", null ],
      [ "SOC_IF_ADC_IN", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654caa8b9679893b182d5dd71c4caa721dd40", null ],
      [ "SOC_IF_MAX", "group___s_o_c.html#gga89be7a04490201d5126d56e0abee654ca16bc074f4ed25208db56eb8c96e35ebc", null ]
    ] ],
    [ "soc_init", "group___s_o_c.html#ga81684839369162675e533a8fdf6c3608", null ],
    [ "soc_pinmux_config", "group___s_o_c.html#ga6cea76f8182eacf4e881337e69b0cf41", null ],
    [ "soc_pinmux_init", "group___s_o_c.html#ga8143323f378a11bc7c29507529add1b7", null ],
    [ "soc_pinmux_set", "group___s_o_c.html#ga6fee5b40bcb3e856732fb0c5358c4d85", null ]
];