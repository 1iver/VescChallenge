var freertos__adapter_8h =
[
    [ "osal_enter_critical", "group___t_a_s_k.html#ga4cb1022e530241f521e6a36f04e62613", null ],
    [ "osal_exit_critical", "group___t_a_s_k.html#gaf770e47fd21e2cd9a9b7041b79b36cc5", null ],
    [ "OSAL_FALSE", "group___c_o_m_m_o_n.html#ga5232862742da87b367422ed4257fca80", null ],
    [ "OSAL_TASK_PRI_HIGHEST", "group___t_a_s_k.html#ga7c0d3abdca716b7a77a273e20d276f33", null ],
    [ "OSAL_TICK_PERIOD_MS", "group___t_i_m_e.html#ga27e46e03894e0b29c1cc2b3647b3976e", null ],
    [ "OSAL_TRUE", "group___c_o_m_m_o_n.html#gaada61dc6c807cba85d8f76698740f69d", null ],
    [ "OSAL_WAIT_FOREVER", "group___c_o_m_m_o_n.html#ga0b0161637f77bdf4434083b4ff6559b6", null ],
    [ "OsalMutex", "group___l_o_c_k.html#gaf8a6faddf39b252e36bc1c7d88f8055c", null ],
    [ "OsalNotify", "group___n_o_t_i_f_y.html#gacd44c52e9bd040d1fc56e92fb2615834", null ],
    [ "OsalSemaphore", "group___s_e_m_a_p_h_o_r_e.html#gae64b322087756ed0398d2f43c08d4e89", null ]
];