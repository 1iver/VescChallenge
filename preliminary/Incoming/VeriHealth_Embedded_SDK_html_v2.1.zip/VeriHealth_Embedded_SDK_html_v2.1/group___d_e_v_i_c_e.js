var group___d_e_v_i_c_e =
[
    [ "DeviceID", "group___d_e_v_i_c_e.html#gabcbb4b07ea8dc6be749296c105e0bd25", null ],
    [ "DeviceID", "group___d_e_v_i_c_e.html#ga414872c624bb3eb10f03bd3a7ece7292", [
      [ "PWR_KEY_DEV_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292aadb220e720c171a6e43f20b50ab4e153", null ],
      [ "PPG_SENSOR_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a2161c1b4481cce5fe12b3afe325a3a9f", null ],
      [ "ECG_SENSOR_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292aba7f14d38713ab4295a53896d0d03eed", null ],
      [ "TMP_SENSOR_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292ada531e39891300937f0739b61240ccd9", null ],
      [ "IMU_SENSOR_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a09631880f9f3cb94a4cb63f2e8ac6484", null ],
      [ "OLED_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a4d8fe80a0e89d7e750decd325907047c", null ],
      [ "PPG_ECG_SENSOR_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a1fef17ff15d393dc956687db8e4a2fef", null ],
      [ "CHARGER_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a23e4e64fab247c5f8d673f81bee90163", null ],
      [ "BATTERY_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a0ab2e745b0fe2ce00c7a98b3762388b4", null ],
      [ "EXT_FLASH_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a54c1ed01aff50c71aaec85a1c6da640a", null ],
      [ "EEPROM_I2C_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a7afdf4c755dad8fe495c29450c97439b", null ],
      [ "EEPROM_I3C_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a75bdb25bb4feb8db6753b713a9644d69", null ],
      [ "LED_PWM_DEV_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292afbd8b89ca572358dcd53672997e37c9b", null ],
      [ "LED_GPIO_DEV_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292a8e4c9c4bea4dd256fb00cd8dbaa867fe", null ],
      [ "MAX_DEVICE_ID", "group___d_e_v_i_c_e.html#gga414872c624bb3eb10f03bd3a7ece7292aee84b67f28a2eb03897f3ec308b12ee8", null ]
    ] ]
];