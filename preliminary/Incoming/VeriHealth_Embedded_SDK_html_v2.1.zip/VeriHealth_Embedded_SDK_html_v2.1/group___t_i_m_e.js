var group___t_i_m_e =
[
    [ "OSAL_TICK_PERIOD_MS", "group___t_i_m_e.html#ga27e46e03894e0b29c1cc2b3647b3976e", null ],
    [ "osal_get_uptime", "group___t_i_m_e.html#ga246ca988446a654c8967d1332179193b", null ],
    [ "osal_get_uptime_us", "group___t_i_m_e.html#ga82eaa81a7641aa45fdedb3aa97abefc6", null ],
    [ "osal_ms_to_tick", "group___t_i_m_e.html#gad30c87abaaab858d73b2fed590e54a99", null ],
    [ "osal_setup_timer", "group___t_i_m_e.html#gaa23a64eb5cd244c2c241f5eeb133df87", null ],
    [ "osal_update_systick", "group___t_i_m_e.html#ga870be6199a94bd3beb20c8b671f2b6b0", null ]
];