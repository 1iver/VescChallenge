var group___s_i_m___i_m_u =
[
    [ "imu_simulator_device_deinit", "group___s_i_m___i_m_u.html#gafb4141364f608045f7d25780b3417e8b", null ],
    [ "imu_simulator_device_init", "group___s_i_m___i_m_u.html#ga526b0434a3b96a0f0667c1397cff1be2", null ]
];