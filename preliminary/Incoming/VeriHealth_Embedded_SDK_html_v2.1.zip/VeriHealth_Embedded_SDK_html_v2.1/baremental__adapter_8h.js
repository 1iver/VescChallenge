var baremental__adapter_8h =
[
    [ "osal_enter_critical", "baremental__adapter_8h.html#a4cb1022e530241f521e6a36f04e62613", null ],
    [ "osal_exit_critical", "baremental__adapter_8h.html#af770e47fd21e2cd9a9b7041b79b36cc5", null ],
    [ "OSAL_FALSE", "baremental__adapter_8h.html#a5232862742da87b367422ed4257fca80", null ],
    [ "OSAL_TRUE", "baremental__adapter_8h.html#aada61dc6c807cba85d8f76698740f69d", null ],
    [ "OSAL_WAIT_FOREVER", "baremental__adapter_8h.html#a0b0161637f77bdf4434083b4ff6559b6", null ],
    [ "OsalMutex", "baremental__adapter_8h.html#af8a6faddf39b252e36bc1c7d88f8055c", null ],
    [ "OsalNotify", "baremental__adapter_8h.html#acd44c52e9bd040d1fc56e92fb2615834", null ],
    [ "OsalSemaphore", "baremental__adapter_8h.html#ae64b322087756ed0398d2f43c08d4e89", null ]
];