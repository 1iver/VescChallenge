var group___d_r_i_v_e_r =
[
    [ "AD1938", "group___a_d1938.html", "group___a_d1938" ],
    [ "DRV_CLOCK", "group___d_r_v___c_l_o_c_k.html", "group___d_r_v___c_l_o_c_k" ],
    [ "DRV_EEPROM", "group___d_r_v___e_e_p_r_o_m.html", "group___d_r_v___e_e_p_r_o_m" ],
    [ "DRV_POWER", "group___d_r_v___p_o_w_e_r.html", "group___d_r_v___p_o_w_e_r" ],
    [ "SIM_IMU", "group___s_i_m___i_m_u.html", "group___s_i_m___i_m_u" ],
    [ "VS_FLASH", "group___v_s___f_l_a_s_h.html", "group___v_s___f_l_a_s_h" ],
    [ "DRV_COMMON", "group___d_r_v___c_o_m_m_o_n.html", "group___d_r_v___c_o_m_m_o_n" ],
    [ "VsdError", "group___d_r_i_v_e_r.html#ga1556c32bfa75f06f54e85db5b47f48b3", null ],
    [ "VsdError", "group___d_r_i_v_e_r.html#gabc6489722251714d2c060d038d069f97", [
      [ "VSD_ERR_GENERIC", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a69d00915e50f17bd008006d1e64b2bc8", null ],
      [ "VSD_SUCCESS", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97ad199ccce49ae7eadd9aa218f1c5a3d03", null ],
      [ "VSD_ERR_NOT_INITIALIZED", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97aadeea7d66a5ff6e19e06e463c0826f87", null ],
      [ "VSD_ERR_INVALID_POINTER", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a148b1b6186cf8c569e7c40168a911703", null ],
      [ "VSD_ERR_INVALID_PARAM", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97ad71b8553a5099e4422eb382b034f2325", null ],
      [ "VSD_ERR_INVALID_DATA", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97acbbbf062878d9cd6bd767fa6e54630ff", null ],
      [ "VSD_ERR_INVALID_CHANNEL", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a21f923f1a853f8ebc14cd96bd7b16172", null ],
      [ "VSD_ERR_INVALID_STATE", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a0f92addb16d122fadb6ba07344daa044", null ],
      [ "VSD_ERR_UNSUPPORTED", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a4e9f504715247e99be1d46d029900c71", null ],
      [ "VSD_ERR_IO", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a67717cff8421a35f954244be3abad52a", null ],
      [ "VSD_ERR_BUSY", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a665148c77f410c0eedadff2e0d6fd206", null ],
      [ "VSD_ERR_NO_MEMORY", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a75443a42fae5fd498412c7a16dd5721d", null ],
      [ "VSD_ERR_FULL", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a40d808309537a7fe960f7d9cf14d2eb0", null ],
      [ "VSD_ERR_EMPTY", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a275447af7e47e86bf076e3d3553d30f1", null ],
      [ "VSD_ERR_ABORTED", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97adefba42e188387e0cba97491c47f3463", null ],
      [ "VSD_ERR_TIMEOUT", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97aad934c8c3ab8a4c107d88fb0f4d5cca1", null ],
      [ "VSD_ERR_NON_EXIST", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97ab8f1f71ca19cae16dd1b510d3e93a1bd", null ],
      [ "VSD_ERR_HW", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97a43a2aac602838858dfceece43fbcc7c0", null ],
      [ "VSD_ERR_LICENSE", "group___d_r_i_v_e_r.html#ggabc6489722251714d2c060d038d069f97abe8c50b9607ea48004fe9b0fb0670136", null ]
    ] ]
];