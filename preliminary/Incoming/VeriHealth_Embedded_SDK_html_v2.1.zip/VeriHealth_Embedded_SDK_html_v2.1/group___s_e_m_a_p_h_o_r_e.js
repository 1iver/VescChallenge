var group___s_e_m_a_p_h_o_r_e =
[
    [ "OsalSemaphore", "struct_osal_semaphore.html", [
      [ "semaphore", "struct_osal_semaphore.html#a12b282f9f004ba5abb31c6bad04b35c1", null ],
      [ "semaphore", "struct_osal_semaphore.html#ae82d376a5dbb9a2faa49088c58081f5d", null ]
    ] ],
    [ "OsalSemaphore", "group___s_e_m_a_p_h_o_r_e.html#gae64b322087756ed0398d2f43c08d4e89", null ],
    [ "osal_init_sem", "group___s_e_m_a_p_h_o_r_e.html#gafddddc441d43cd50ce7c5661f1b206c1", null ],
    [ "osal_sem_post", "group___s_e_m_a_p_h_o_r_e.html#ga1607686244ac6fd980a43fae458b1ca2", null ],
    [ "osal_sem_post_isr", "group___s_e_m_a_p_h_o_r_e.html#gac745f760ca625243b4219603b112771c", null ],
    [ "osal_sem_wait", "group___s_e_m_a_p_h_o_r_e.html#ga45be959d7990381c6d35c42ca2680af0", null ]
];