var group___a_u_d_i_o =
[
    [ "SND_SOC_DAIFMT_CBM_CFM", "group___a_u_d_i_o.html#ga64c2e3ef83a8a02e0e034cbcc7fe66df", null ],
    [ "SND_SOC_DAIFMT_CBM_CFS", "group___a_u_d_i_o.html#ga41c0cb47a1254c79ffcb8f2068f8b505", null ],
    [ "SND_SOC_DAIFMT_CBS_CFM", "group___a_u_d_i_o.html#ga1bf4fa61cb5205935641480f64b24a55", null ],
    [ "SND_SOC_DAIFMT_CBS_CFS", "group___a_u_d_i_o.html#gafada8bdaba7b7101e1226ec4842ed6d5", null ],
    [ "SND_SOC_DAIFMT_DSP_A", "group___a_u_d_i_o.html#gaff07ca8b2c679d5903a221e98af7a8a4", null ],
    [ "SND_SOC_DAIFMT_FORMAT_MASK", "group___a_u_d_i_o.html#ga8da3667353474d0f7f7f725e972f8261", null ],
    [ "SND_SOC_DAIFMT_I2S", "group___a_u_d_i_o.html#gae2148663d2cafada03136586f4e4d50d", null ],
    [ "SND_SOC_DAIFMT_MASTER_MASK", "group___a_u_d_i_o.html#ga654d405aeac8ca638f5e249a160d6864", null ],
    [ "SND_SOC_DAIFMT_PDM", "group___a_u_d_i_o.html#ga5fd63a5128fdeaed6052d22d718b0a8f", null ]
];