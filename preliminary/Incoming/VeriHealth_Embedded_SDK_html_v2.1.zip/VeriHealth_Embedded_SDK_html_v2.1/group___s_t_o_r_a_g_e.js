var group___s_t_o_r_a_g_e =
[
    [ "VpiStgInfo", "struct_vpi_stg_info.html", [
      [ "block_size", "struct_vpi_stg_info.html#a187490d33fcd3504100c98ea46de5e60", null ],
      [ "device_size", "struct_vpi_stg_info.html#a7312c7cd26823f792a47672677e58b74", null ],
      [ "page_size", "struct_vpi_stg_info.html#a46db0aa98eee6ea5408a86a8b92a45ab", null ],
      [ "sector_size", "struct_vpi_stg_info.html#ae5cc214e2b6bdc8dc020f1ac247384da", null ],
      [ "type", "struct_vpi_stg_info.html#a2c6668374c046074dad7f2537549d3b6", null ]
    ] ],
    [ "VpiStgInfo", "group___s_t_o_r_a_g_e.html#ga506b77ba5705666a66d022b61b8f5eaf", null ],
    [ "VpiStgPwrMode", "group___s_t_o_r_a_g_e.html#gac66c7ebc0b8cf8252390c858881d2d9b", [
      [ "STORAGE_PWR_DYNAMIC", "group___s_t_o_r_a_g_e.html#ggac66c7ebc0b8cf8252390c858881d2d9ba11de4036cd8a136aa642ae3b1e003eaf", null ],
      [ "STORAGE_PWR_SLEEP", "group___s_t_o_r_a_g_e.html#ggac66c7ebc0b8cf8252390c858881d2d9baf02dd1bf0efca8745d06fcf0e388f6f8", null ],
      [ "STORAGE_PWR_ALWAYS_ON", "group___s_t_o_r_a_g_e.html#ggac66c7ebc0b8cf8252390c858881d2d9ba153004d5f5382d919c521c3b6597af72", null ],
      [ "STORAGE_PWR_DEFAULT", "group___s_t_o_r_a_g_e.html#ggac66c7ebc0b8cf8252390c858881d2d9baa56a230e1e5403a7bc9f5baf0955c0eb", null ],
      [ "STORAGE_PWR_MAX", "group___s_t_o_r_a_g_e.html#ggac66c7ebc0b8cf8252390c858881d2d9ba9702d27e991a417b7b232c57ad51da9d", null ]
    ] ],
    [ "VpiStgType", "group___s_t_o_r_a_g_e.html#ga8496ce23704ca1fb8a94ae85786dc033", [
      [ "STORAGE_TYPE_NOR", "group___s_t_o_r_a_g_e.html#gga8496ce23704ca1fb8a94ae85786dc033a57566d2d709cbf8b3c007e4992da27f8", null ],
      [ "STORAGE_TYPE_NAND", "group___s_t_o_r_a_g_e.html#gga8496ce23704ca1fb8a94ae85786dc033ab761ffe2510e074ac1fef206174028d3", null ],
      [ "STORAGE_TYPE_MAX", "group___s_t_o_r_a_g_e.html#gga8496ce23704ca1fb8a94ae85786dc033a9d02f6a72e643688f6ee32d2d8c50e35", null ]
    ] ],
    [ "vpi_storage_erase", "group___s_t_o_r_a_g_e.html#gac4f57911de108c75a9fb48a7bc0d82a9", null ],
    [ "vpi_storage_get_imginfo", "group___s_t_o_r_a_g_e.html#ga37cd4386e3614e6aded06f6ce34525f6", null ],
    [ "vpi_storage_get_info", "group___s_t_o_r_a_g_e.html#ga5500fc1b0d711ec000a7a1cfbd02addd", null ],
    [ "vpi_storage_init", "group___s_t_o_r_a_g_e.html#ga98c32926740a49ae50e1be29180c98bf", null ],
    [ "vpi_storage_power_mode", "group___s_t_o_r_a_g_e.html#ga928ae92e28dc116e93326d29bf0ab69d", null ],
    [ "vpi_storage_print_imginfo", "group___s_t_o_r_a_g_e.html#gaedfa082a92382e16adafd72e9f050ceb", null ],
    [ "vpi_storage_read", "group___s_t_o_r_a_g_e.html#gaac7df0a2c89c0d6352a54005be9c2440", null ],
    [ "vpi_storage_show_img_info", "group___s_t_o_r_a_g_e.html#ga36116fe7ccc5512a485e95819135d9d3", null ],
    [ "vpi_storage_verify_img", "group___s_t_o_r_a_g_e.html#ga76601582d7a52fd931a72092d1969e28", null ],
    [ "vpi_storage_write", "group___s_t_o_r_a_g_e.html#ga765549154ff218bf044b4ad5a29755ff", null ]
];